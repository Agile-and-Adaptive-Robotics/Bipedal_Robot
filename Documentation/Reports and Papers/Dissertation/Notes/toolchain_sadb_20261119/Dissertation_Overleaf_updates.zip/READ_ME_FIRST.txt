Updating the existing Bolen-Dissertation project in Overleaf

1. Apply the supplied source files to the matching existing paths in your project.
   The review folder also contains OVERLEAF_SOURCE_CHANGES.diff for use with tracked edits or comments.
  chapters/01-copyright.tex
  chapters/50-database.tex
  chapters/60-sns.tex
  chapters/70-overall.tex
  chapters/95-AppendixD.tex
  chapters/96-AppendixE.tex
  main.tex
  psutex.cls

2. Merge the contents of figs/ into the matching folders beneath figs/ in Overleaf.
   The PDF graphics must be uploaded as files. The .txt companions describe the figures.
   The package includes font repairs outside Chapters 5–7.

3. Append the entry in Chomsky_2023.bib to your existing thesis.bib if the key
   chomsky_false_promise_2023 is absent. The supplied project already includes ong_predicting_2019.

4. Recompile main.tex. The Abstract should read i. In Chapter 7, Figure 7.2C is the
   exploded BPA and Figure 7.5 shows how to repeat a controlled simulation experiment.

Locally, four superseded Chapter 5 snapshots are stored in Deprecated. If you keep the same
archive in Overleaf, move the following old figs/50-database/ files after updating Chapter 5:
  sadb_clusters_app.png
  sadb_pivot_app.png
  sadb_table_detail.jpg
  sadb_table_record.jpg
