from collections import defaultdict
from pathlib import Path
import pdfplumber
from sys import argv

pdf = Path(argv[1])
with pdfplumber.open(pdf) as doc:
    for raw in argv[2:]:
        paper = int(raw)
        page = doc.pages[paper+19]
        byfont = defaultdict(list)
        for c in page.chars:
            if c["top"]<70 or c["bottom"]>680 or c["text"].isspace():
                continue
            # pdfminer reports the length of the graphical y-axis as "size";
            # after a 90-degree text rotation that length is the glyph width.
            # Horizontal text establishes a lower bound on readable label sizes.
            if not c["upright"]:
                continue
            k=(c["fontname"].split("+")[-1],round(c["size"],2))
            byfont[k].append(c)
        print(paper, "raster",len(page.images))
        for k, group in sorted(byfont.items(), key=lambda x:(x[0][1], x[0][0])):
            if len(group)<4:
                continue
            print(k, len(group), round(min(c["top"] for c in group)), round(max(c["bottom"] for c in group)), ''.join(c["text"] for c in group)[:42])
