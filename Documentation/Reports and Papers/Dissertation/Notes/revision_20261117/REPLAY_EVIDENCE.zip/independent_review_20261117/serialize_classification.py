"""Serialize the independent language model's explicit, passage-level decisions.

No model scoring or keyword-based issue detection is delegated to this formatter.
The project review and manuscript snapshots supply all source text.
"""
import collections
import hashlib
import json
from pathlib import Path

from inspect_material import SOURCE, ROOT, narrative_units

NOTES = ROOT / "Documentation/Reports and Papers/Dissertation/Notes/revision_20261117"
LIVE = NOTES / "LIVE_REVIEW.json"
OUTPUT = NOTES / "CLASSIFIER_RESULTS.json"
LIVE_TEX = ROOT / "tmp/dissertation_revision_20261117/live"

PROMPT = """Read the original chapter or appendix in context and then read each narrative unit and the surrounding technical evidence. First classify the individual real feedback events from the open project review, using ajh26 as the advisor. Score each distinct tracked replacement −1 on its original wording. Score each individual non-praise message on what that message itself asks for: −1 for wording or clarification, −2 for a substantive revision, and −3 for a factual or interpretive error. A pure compliment scores 0; a mixed message takes the negative class of its requested correction. Link correlated signals to the same unique issue, but retain each individual event. Keep other authors' changes and comments separate. Preserve exact highlights, original and proposed text, and individual comment text.

Then inspect original prose whose content is not itself an identified advisor mark. Predict whether an ME dissertation reader would lack context, confuse authorship or functions, be unable to reproduce the example, misunderstand a scientific comparison, or lose the argument to caveats, repetition, vague terminology, or ungrounded future work. Read the whole passage, its method and result, and the surrounding section. Preserve design assumptions, attribution, experimental failures, source and protocol distinctions, and qualifications that materially change interpretation. Use the same three negative severities as inspection priorities only. Do not infer approval, a numeric zero, or an advisor label from an unmarked passage. If no new issue warrants an individual change, return no flag and a null score. Record the specific reason for each flag. Keep independent predictions separate from Ben's explicit directives and from observed advisor events. In a separate reread, compare the revised evidence at the appropriate level against the relevant criticism."""

# Primary reasons named by the model after reading the complete baseline. Each
# row below identifies the exact place the assessment applies. Unlisted units
# were also read, and no issue was selected for them in this screening.
# (issue, predicted severity, rationale and recommended action)
reviews = {
 "60-sns.tex": {
  11: ("credit",-1,"The transfer and course-project credits are useful; distinguish the joint work, the individual toe change, and the conference presentation."),
  27: ("function",-2,"The motivation names diagnostic difficulties. Name one operation the researcher gained, such as rerunning the same controller after a pathway deletion."),
  29: ("function",-2,"The contribution list lacks a named callable artifact and a test result. Pair an authored component with the prior platform and a task."),
  35: ("context",-1,"The general sequence can point directly to the first prepared model and signals on the drawing instead of listing abstract stages twice."),
  44: ("interface",-2,"Separate CAD assembly, OpenSim conversion, and runtime signal exchange. In the main explanation name what the Simulink controller commands and reads from MuJoCo."),
  46: ("identity",-1,"Place the historical selector and network-size details in the relevant identity or timing record; keep the body and controller identifiable in prose."),
  65: ("function",-2,"A future universal graphical application distracts from the available components. Explain what a colleague can open and run now."),
  92: ("caveats",-1,"Keep the pressure–length force assumption and identify the missing valve state once; the final general statement repeats the comparison principle."),
  105: ("interface",-2,"A concrete trip around one actual loop would make the signal types operational for a new reader."),
  107: ("database",-1,"Replace the generic list of pathway possibilities with a pointer to the demonstrated evidence search; make the gain an experimental choice."),
  109: ("interface",-1,"Preserve the command/readback direction; the three timesteps belong with their own tests and can be referenced from one place."),
  113: ("terminology",-1,"Define the measurable PF feature in ordinary language before listing onset, overlap, and transmission."),
  136: ("repetition",-1,"This rule is restated around the original PF failure and again in the discussion. Attach it to the observed failure."),
  140: ("terminology",-1,"If the search method is retained, explain what it chose in one actual experiment; a generic optimizer lesson adds little."),
  142: ("terminology",-1,"Replace 'protected joint bounds' and 'sufficient interval duration' with the knee and duration criteria or a direct appendix pointer."),
  144: ("repetition",-1,"Several lists say to declare the varied quantity. Let the fixed-pathway comparison show how recording a perturbation permits interpretation."),
  146: ("timing",-1,"The necessary timing distinction is given again with the numbers; introduce the distinction briefly and keep precise scopes in the result."),
  155: ("caveats",-1,"Keep the negative R² values and matched-pose limitation; 'useful agreement and important remaining ... differences' restates the numbers."),
  157: ("function",-1,"Explain what one measured return signal permits the block-programmed controller to do. Keep the full array comparison in D."),
  163: ("caveats",-1,"Use agreement of ten bursts and the shared heel input as the result; present the 2 ms best-lag scope once."),
  165: ("reproduction",-2,"The reader can judge the transient but cannot find its graded replay invocation here. Add one named entry point or direct worked-example reference."),
  174: ("reproduction",-2,"This is a strong input–output experiment. Identify the loaded-arm implementation and explain how to find its response, or point to the chosen reproducible example."),
  185: ("identity",-2,"A first-time reader must untangle a revised controller, software compatibility, and command histories. State that both commands and sensory return changed before comparing the air trials."),
  194: ("support",-1,"Keep the original weight denominator where the percentage is reported. Move bookkeeping to D and explain that suspension carried nearly all weight."),
  196: ("caveats",-1,"The stated noise levels and mechanical state bound the claim. State the consequence of six successful trials without adding an unrelated list of untested conditions."),
  198: ("phase",-1,"A clear phase effect sits inside timing bookkeeping. Lead with the transmission threshold; keep the observation window with its numerical measurement."),
  202: ("phase",-1,"Keep the two contact phases, unchanged controller, and the common push. The shared pulse is an important matched condition."),
  212: ("phase",-2,"Say what PF channels should send and why a successful MN fit can hide failed timing; PCA rank is secondary evidence."),
  214: ("phase",-2,"The sequence of a gain-only failure, offline timing repair, and failure in the moving model can be expressed before the competing denominators."),
  216: ("credit",-1,"Name the published Rybak mechanism and what the reduced implementation reproduced: a lost burst with retained phase versus a shifted rhythm."),
  220: ("support",-2,"Give the body, alternating unloaded swings, and retained support together; separate whole-trial signed force from upward force in the scored interval."),
  222: ("caveats",-1,"Preserve why the short-shuffle target failed; the statement about another controller repeats the preceding identification."),
  224: ("identity",-1,"Identify force allocation and ideal reference tensions before reporting the CAD motor result so the reader knows what produced the movement."),
  233: ("caveats",-1,"Five of eight tested perturbations already define the local result. The following disclaimer can be replaced by which margin stopped the other three."),
  237: ("timing",-2,"Separate the one complete-process comparison, its neural-call portion, and the later kernel/evaluator timings; refer to the table for repeated values."),
  255: ("timing",-2,"The performance table and appendix already report the scopes. Use the contrast between the kernel and evaluator timings to explain where acceleration helped."),
  261: ("repetition",-1,"The same inventory appears in the overview and conclusion. Lead with one result that changed an engineering decision."),
  263: ("phase",-1,"The failed timing after closing the loop is stronger than the summary 'evidence is cumulative'. Open with that observation."),
  265: ("function",-2,"Generic claims for graphical versus scripted work can be replaced by how one circuit block and an experiment driver work together."),
  269: ("caveats",-1,"Keep the boundary between an implemented response and physiological validation once; the generic taxonomy repeats the detailed results."),
  271: ("support",-1,"Provide one cross-model interpretation of support, while preserving each cited experiment's conditions at its result."),
  273: ("caveats",-1,"Actuator distinctions are useful. Point to the model table and name one inference changed by using ideal tension instead of calibrated BPA force."),
  277: ("future",-1,"Specify the measured PF requirement that precedes whole-body tuning; omit a general reminder that prior examples do not complete future work."),
  279: ("future",-1,"Select one mechanical discrepancy and its matched dynamic test instead of repeating the broad development list."),
  285: ("repetition",-2,"A second inventory of tools/results repeats the preceding discussion; close with the transferred-controller question the experiments now let a researcher answer."),
 },
 "70-overall.tex": {
   6: ("context",-1,"The opening spans adaptation, biomedical uses, and research ethics in one paragraph. Lead with the interaction between actuator loading and feedback."),
   8: ("function",-1,"Replace the abstract 'different sources of uncertainty' with what one predicts mechanically and what one can test neurally."),
   21: ("caveats",-1,"Present the measured resting-length contribution, then let the next subsection identify dynamic work without a preemptive disclaimer."),
   27: ("future",-1,"Name what each proposed motion or load control measures instead of listing test families."),
   29: ("fea",-3,"The cited Festo entry is a product datasheet, and cap compliance and end-transition effects are different hypotheses. Specify the FEA and physical tests independently."),
   45: ("pulley",-2,"Apply Ben's exact deletion, use pulley-assisted BPA routes, and state what routing changes mechanically."),
   47: ("chi4",-3,"Ben reports that the added force-path stiffness was already tested without benefit. Remove the proposal and preserve the earlier fit as provenance."),
   49: ("power",-2,"State why synchronized dynamic torque and angular velocity matter, give P=τω and sign convention, and tie the dynamometer/loading proposal to delivering or absorbing power."),
   53: ("database",-2,"Demonstrate the navigation claim with an actual pathway, paper, conditions, and an engineering inference. Remove the immediate unrelated qualification."),
   57: ("database",-1,"The cluster-layout plan and field inventory crowd the practical research use; distinguish implemented monthly search from a proposed layout."),
   59: ("caveats",-2,"The disclaimer about an unclaimed number of missing sources interrupts the argument. Preserve the source-checking practice in the curation section."),
   63: ("credit",-2,"Identify the Li mechanics, Deng controller, Morrow/Bolen transfer, and loss of support. Name one authored tool used to examine a failure."),
   65: ("support",-3,"The paragraph's 'coupled balance and locomotor behaviors' can imply independent balance from assisted stepping. Name supported in-place human stepping, continuing shared drive, and separate robot progression."),
   69: ("phase",-1,"Connect the future layer intervention to the existing missing-burst mechanism and keep controls fixed explicitly."),
   73: ("future",-1,"Name the sensor, state estimate, and task in which its contribution would be compared; both generic modality weighting and drift need context."),
   75: ("future",-1,"Choose the behavioral variable for the cited adaptive controller; anatomically more detailed networks are not themselves an experimental aim."),
   86: ("interface",-2,"A physical embedded controller connected to simulated mechanics is controller hardware-in-the-loop; name the physical component, simulated model, and exchanged signals."),
   95: ("future",-1,"Relate returned signals and latency to a proposed joint test; a hardware inventory is less informative."),
   97: ("caveats",-1,"Other robots are precedents. Say what their work motivates without an immediate defense against an unmade validation claim."),
   105: ("repetition",-1,"The final paragraph repeats the opening four contributions. End with a concrete next coupled measurement."),
 },
 "92-AppendixA.tex": {
   4: ("trace",-1,"The scope is the mechanical equations and sources named here; avoid promising that this appendix traces every number in the dissertation."),
   79: ("caveats",-1,"The shape factors and their effects are informative. Integrate the definition with the table rather than repeating every distinction."),
   120: ("torque",-3,"The sentence equates torque targets (N m) with excursion moment arms (m). State signed r=−∂l/∂θ, then construct τref=F0 r."),
   159: ("trace",-1,"Keep the file references but remove the bracketed editorial 'Provenance' aside from the equation definition."),
   171: ("trace",-1,"Separate the implemented zero clamp from the unused 40 mm coefficient set; identify historical code data without implying it entered the study."),
   187: ("torque",-3,"The cross product is the full moment vector. State the component about the knee axis, and restrict the planar arm formula to the geometry it describes."),
   198: ("frames",-3,"Distinguish the recorded two-rotation fit from the current standalone evaluator's one rotation at each attachment; identify the implementation supporting each statement."),
   205: ("tendon",-2,"The n=2 and ×6 phrasing could imply twelve strands. The cited source sets a total multiplier of six for 20 mm and two otherwise."),
 },
 "93-AppendixB.tex": {
   66: ("identity",-1,"Name the model in which unused electrical synapse types are defined; availability in a file does not identify the path exercised."),
   70: ("credit",-1,"Distinguish the published toolbox implementation from the assembled 410-neuron circuit and distinguish its graded cells from archived spiking Simulink examples."),
   88: ("identity",-1,"The original analog current and the calibrated spiking threshold adaptation are different mechanisms. Keep their operating-point relationship explicit."),
   112: ("terminology",-1,"Tie the spike-detection threshold rule to this particular sampled reset block and define the two membrane-voltage coordinate frames."),
   141: ("terminology",-1,"Prefer the sustained rhythm and missed cadence results to 'gate set', 'clauses', and 'tuning knobs'. Preserve the complete numerical table."),
   168: ("trace",-1,"If the implementation detail stays, explain the failure that changing the connection class fixes in one sentence."),
   200: ("future",-2,"The assertions about every gain and unattempted variants are peripheral and are not measured outcomes. Keep the tested conversion and necessary retuning."),
   205: ("identity",-1,"Place the 96-cell saved configuration next to its replay before contrasting it with the independent 95-cell core and the 108-cell model."),
 },
 "94-AppendixC.tex": {
   4: ("trace",-1,"Preserve Ben's CAD choice and its effect on fitted stiffness; avoid the broad 'any value' claim."),
   13: ("trace",-1,"Move the bracketed provenance into a concise source note so the coordinate transformation can be read uninterrupted."),
   19: ("fold",-1,"This is the first of several repetitions of held-out and unused tests. State the split once at the results table and cross-reference it."),
   21: ("fold",-1,"Keep the encoder offset and precise exclusion of the 47 cm test; reference the consolidated training/validation table."),
   79: ("fold",-1,"The same extensor split is stated on lines 19 and 267. Preserve the numeric division at its authoritative location and shorten the repeated prose."),
   159: ("caveats",-1,"Distinguish measured cable dimensions and effective prediction inputs once, at the equation; retain the actual 20 and 21 mm quantities."),
   178: ("frames",-3,"The general two-axis construction applies to the fitted version but cannot be attributed to every evaluator; identify which convention is documented."),
   194: ("frames",-3,"The archived front and the current standalone evaluator implement different rotations. Identify the fit source before interpreting anisotropic stiffness."),
   219: ("frames",-3,"Cite the fitting evaluator's two-rotation branches for the source column and retain the K arrays independently of frame provenance."),
   238: ("trace",-1,"The closing parenthesis repeats that only length and wrapping varied in the paired extensor fit. Keep the actual fit constraint once."),
   317: ("trace",-1,"The event-pose versus first-inactive distinction matters; a remark about plot-title metadata does not explain the measured geometry."),
   321: ("trace",-1,"Keep geometry and the active route. Animation file sizes do not change interpretation."),
   341: ("route",-3,"The implemented test uses planar geometry, one crossing segment, and a monotonic angle sweep. Restrict 'any wrapped actuator route' to those assumptions."),
   351: ("route",-1,"An atan2 signed angle still has a branch at ±π. Say which orientation-subtraction problem is avoided rather than claiming no possible seam."),
   379: ("route",-2,"Differentiate the first inactive forward grid pose and the inferred reverse activation angle; the reverse traversal of a stored record is not a measured re-engagement."),
   381: ("route",-1,"The adjacent equation uses radius times angle to obtain length. Replace 'arc length over its effective radius' with that dimensional statement."),
   386: ("route",-3,"A planar, monotone one-crossing algorithm does not transfer unchanged to arbitrary 3-D or multi-joint routes."),
 },
 "95-AppendixD.tex": {
   4: ("context",-1,"A one-sentence reason to consult this appendix and a route to the worked example would help a first-time modeler."),
   36: ("caveats",-1,"Keep the distinction between repaired active scale and unchecked length range; omit a repeated warning about measured BPA capacity."),
   44: ("repetition",-1,"The boundaries are repeated in the next matched-pose section, which states the actual controlled variables."),
   81: ("caveats",-1,"The absence of matched velocity dynamics is important. State once that a sample lag cannot identify biological tendon delay."),
   96: ("interface",-1,"Identify the bridge as runtime exchange and the separate model-conversion step in a positive statement."),
   102: ("repetition",-1,"This abstract verification rule immediately precedes the actual matched-input HCO test; use the test conditions to introduce it."),
   106: ("repetition",-1,"Keep sample horizon, processing lag, and latching in D; shorten the duplicate main-chapter version."),
   131: ("phase",-1,"The specific Rybak resetting and non-resetting responses explain the scientific benchmark better than a count of checks."),
   168: ("identity",-1,"Use the common original RG and later bilateral RGs to identify the source and transfer configurations before comparing them."),
   184: ("record",-2,"Keep physical conditions separate from fitting steps, and qualify which saved configurations actually retain the complete input history."),
   190: ("credit",-1,"Hunt supplied the calibration procedure. Software selector 'hunt' is a compatibility detail and belongs in the reproduction note."),
   192: ("record",-1,"The missing launch traces materially limit causal interpretation. Preserve this restriction explicitly alongside the documented command and afferent differences."),
   210: ("support",-1,"Retain both recorded weight definitions, the post-startup interval, and zero ground force. Present the two denominators side-by-side so a reader can reproduce them."),
   216: ("phase",-1,"Define the 3.4 s paired window once, then show which voltage was affected and whether it crossed the outgoing threshold."),
   246: ("terminology",-1,"Explain what the onset/shutoff circuitry computes before listing cell names; identify the external scheduler distinctly."),
   267: ("phase",-1,"Group offline, transmitted, and body acceptance outcomes by what was tested. The 30 live checks have a different denominator."),
   271: ("support",-1,"Retain 29.519% versus 35.069% with their different signs/windows, side-specific knee minima, and the impact concern. A compact condition table would aid reuse."),
   313: ("support",-1,"Retain shared drive at 2.0773 nA and distinguish robot progression under its own support. This is a material bound on the inference."),
   320: ("flow",-2,"The paragraph jumps from supported mechanical stepping to an isolated warm neural benchmark. Move the timing material into the execution section."),
   324: ("phase",-1,"The unchanged underlying forward pulse is essential. Separate the control facts from the inventory of individual pathway interventions."),
   345: ("flow",-1,"Separate controller implementation from the local perturbation evidence, missing binary, and soft-contact penetration measurements."),
   347: ("caveats",-1,"The older 80% and newer 77.5% runs are different comparisons. Identify the matched older control once rather than narrating which example superseded another."),
   353: ("repetition",-2,"Preserve native Di Russo/SCONE replay and the rejected transfer search, state their chronology, and remove the repeated interpretation in the final two sentences."),
   393: ("trace",-1,"A brief pointer to the settled response suffices; version-management history is secondary."),
   425: ("timing",-1,"Keep complete process versus a component of the same paired workload together with its actual duration and array agreement."),
   427: ("timing",-1,"The median warm-kernel runs and single evaluator diagnostic use distinct timers. Use a compact scope note rather than two repeated throughput disclaimers."),
   429: ("record",-3,"Claiming that full records preserve actual input samples conflicts with the explicitly unrecovered air-stage histories on line 192. State the exception."),
   462: ("reproduction",-2,"A directory legend and handoff identify code but do not specify a first runnable command, settings, output, and success criterion."),
 },
 "96-AppendixE.tex":{
   4: ("caveats",-1,"State which snapshot is being summarized; the caveat about estimating the entire literature is unnecessary."),
   8: ("snapshot",-1,"Name the five categories and the retained snapshot; attribute the former 1,000-record limit to the plan used at the time."),
   14: ("caveats",-1,"Use the citation graph for finding papers. State the difference between a cited paper and an observed mechanism in the worked example."),
   20: ("database",-2,"Use actual paper records to distinguish the database pathway label from the observed preparation, stimulated nerve, and target motor pool."),
 },
}
issue_titles = {
 "context":"Introduce the system before diagnosing a failed connection",
 "interface":"Connect a controller and mechanical model through named signals",
 "function":"Attribute each contribution and give it a use and test",
 "credit":"Credit the prior model, method, and new implementation",
 "identity":"Keep controller, mechanical model, actuator, and test identifiable",
 "caveats":"Retain qualifications that change a result, once",
 "trace":"Keep implementation provenance usable without interrupting the mechanism",
 "terminology":"Name the physical or computational operation in engineering language",
 "repetition":"Replace repeated conclusions with evidence or a cross-reference",
 "timing":"Tie each runtime result to the timed workload and comparison",
 "database":"Trace a named pathway to its source and its conditions",
 "reproduction":"Give one runnable coupled model with inputs and expected readout",
 "phase":"Describe the timing mechanism, intervention, and controlled outcome",
 "support":"Specify actual assistance and what the experiment showed",
 "future":"Define a measurable next question",
 "fea":"Separate cap compliance, end-region mechanics, and the FEA test",
 "pulley":"Use pulley-assisted routing and honor the explicit deletion",
 "chi4":"Remove the already-tested extra-stiffness recommendation",
 "power":"Measure joint power during controlled movement",
 "torque":"Distinguish moment arm, moment vector, and signed joint torque",
 "frames":"Distinguish the fitting frame conventions from the standalone evaluator",
 "fold":"Identify training, validation, and unused tests once",
 "route":"State the implemented geometry, reversibility, and dimensional limits",
 "record":"Specify which original inputs and replay evidence were retained",
 "flow":"Keep comparable measures and scientific questions together",
 "snapshot":"Specify the database snapshot, count, and denominator",
 "tendon":"State the total parallel cable multiplier for each actuator size",
}


def actual_feedback(live):
    output = []
    for entry in live["entries"]:
        if entry["author"] != "ajh26":
            continue
        if entry["kind"] == "thread":
            for message in entry["messages"]:
                first = message["comment_id"] == "6afcc30a369865f771e5389c"
                output.append({"id":"AD-C1" if first else "AD-C2", "category":"advisor_comment",
                               "issue":"context", "file":entry["file"], "review_offset":entry["offset"],
                               "anchor":entry["anchor"], **message,
                               "original_score":-1 if first else -2,
                               "reason":("A short request to supply missing context. The follow-up specifies the extent of the necessary revision."
                                         if first else "Requests a substantive new sequence beginning with the composition of the simulation before discussing what changes during transfer.")})
        else:
            i = len(output) + 1
            output.append({"id":f"AD-T{i}", "category":"advisor_tracked_edit",
                           "issue":"context" if i==1 else "interface", **entry,
                           "original_score":-1,
                           "reason":"Changes the description of the earlier AnimatLab work from controller-transfer work to controller development work, in the new introductory paragraph." if i==1
                                    else "One of the two linked replacements that describe connecting a controller with its model."})
    return output


def package():
    raw = LIVE.read_bytes()
    live = json.loads(raw.decode("utf-8-sig"))
    scored = actual_feedback(live)
    originals = []
    details = {}
    for path in sorted(SOURCE.glob("*.tex")):
        livepath = LIVE_TEX / path.name
        details[path.name] = {"pre_edit_git_checkout_raw_sha256":hashlib.sha256(path.read_bytes()).hexdigest(),
                              "live_editor_text_utf8_lf_sha256":hashlib.sha256(livepath.read_text(encoding="utf-8-sig").encode("utf-8")).hexdigest()}
        units = list(narrative_units(livepath))
        by_line = reviews[path.name]
        original_units = list(narrative_units(path))
        if set(by_line) - {u["start"] for u in original_units}:
            raise ValueError(f"Orphan line verdict in {path.name}")
        for rec in units:
            k = rec["start"] - 2 if path.name=="60-sns.tex" else rec["start"]
            record = dict(rec, advisor_label=None, predicted_severity=None,
                          predicted_issue=None, model_reason=None)
            if path.name=="60-sns.tex" and rec["start"]==7:
                shown = record["input"]
                original = shown.replace("Earlier controller development work","Earlier controller-transfer work").replace(
                    "connect neural outputs with actuator commands","translate neural outputs into actuator commands")
                assert "Earlier controller-transfer work" in original and "translate neural outputs into actuator commands" in original
                record.update(status="observed_tracked_edit_anchor",advisor_signals=["AD-T1","AD-T2","AD-T3"],
                              recorded_live_proposed_paragraph=shown, input=original,
                              input_sha256_utf8_lf=hashlib.sha256(original.encode("utf-8")).hexdigest())
            elif path.name=="60-sns.tex" and rec["start"]==11:
                record.update(status="observed_comment_anchor", advisor_signals=["AD-C1","AD-C2"])
            elif k in by_line:
                key, severity, reason = by_line[k]
                if path.name=="60-sns.tex" and rec["start"]==279:
                    reason = "The live revision asks for opportunities. 'The controller next step' obscures the measurable condition: establish PF timing in the body before fitting later motor output."
                if path.name=="60-sns.tex" and rec["start"]==281:
                    reason = "The live phrase 'another tract for development' is awkward. Name the force discrepancy or pressure transient and its matched measurement."
                record.update(status="unlabeled_flagged_for_inspection",predicted_issue=key,
                              predicted_severity=severity,model_reason=reason)
            else:
                record["status"]="unlabeled_no_new_flag"
            record["git_start"]=None if path.name=="60-sns.tex" and rec["start"]==7 else k
            originals.append(record)
    c6 = (LIVE_TEX / "60-sns.tex").read_text(encoding="utf-8-sig")
    lines = c6.splitlines()
    for event in scored:
        offset = event.get("offset",event.get("review_offset"))
        pos = c6.count("\n",0,offset)+1
        expected = event.get("proposed",event.get("anchor"))
        assert c6.startswith(expected,offset),(event["id"],offset)
        event["live_line"]=pos
        event["live_tex_excerpt"]=lines[pos-1]
        event["related_issue_grouping"]="Analyst grouping of feedback about introduction/earlier work" if event["issue"]=="context" else "Two separate edits in one command-interface phrase"
    totals = collections.Counter(rec["status"] for rec in originals)
    return {
     "model_identity":"OpenAI Codex, GPT-6 family, independent dissertation reviewer subagent; exact deployed checkpoint, sampling settings and version were not exposed",
     "method":"Direct passage judgments by the language model in this session. The local formatter copied its explicit decisions, exact text inputs, and line anchors. No external API, fitted model, keyword scorer, or statistical calibration.",
     "prompt":PROMPT, "rubric":{"advisor_tracked_edit":-1,"wording_or_clarification":-1,
                               "substantive_revision":-2,"factual_or_interpretive_error":-3,
                               "pure_praise":0,"mixed_comment":"negative class of requested change",
                               "unmarked":"unlabeled; model inspection priority -1/-2/-3, or null for no new issue"},
     "project":live["project"],"capture_utc":live["capture_utc"],"review_capture":"LIVE_REVIEW.json",
     "review_capture_sha256":hashlib.sha256(raw).hexdigest(),
     "source":"Final/chapters at commit 316dea36d83919c535908cd954d2381c37006845 was first independently read and cross-checked with the complete live pre-edit capture (2026-11-18T00:29:14.183Z). Paragraph outputs below use that live text and live line numbers. Only Chapter 6 differs among the seven sources. At its line 7 the captured editor shows the proposed wording; the exact pre-replacement paragraph was reconstructed from the three tracked originals. Each per-unit text digest uses unescaped UTF-8 with LF between lines and no terminal newline.",
     "source_snapshots":details,"unit":"A narrative paragraph or prose segment adjacent to a displayed equation. TeX structural material, equation bodies, captions, tables, and list items were excluded from the exhaustive prose screen and reviewed separately when relevant.",
     "known_anchor_rule":"Observed original tracked edits are at the same new introductory paragraph at live line 7, with proposed strings checked directly at character offsets 440, 707, and 730. The advisor thread's exact highlighted text starts at live line 11, offset 1506. Neither marked paragraph entered the prediction pool. All remaining units retain a null advisor label; authorship and extracted times alone never assign an advisor label to unmarked text.",
     "other_authors":{"bbolen83":"363 tracked edits, author's own changes; excluded from advisor scoring",
                      "leo.micklem":"20 nonadvisor comment threads across the live project; retained in LIVE_REVIEW.json"},
     "advisor_signals":scored, "observed_total":sum(v["original_score"] for v in scored),
     "observed_unique_issues":{"context":["AD-T1","AD-C1","AD-C2"],"interface":["AD-T2","AD-T3"]},
     "issue_catalog":issue_titles,"user_directive_overlaps":["fea","pulley","chi4","power","database","reproduction"],
     "prose_counts":dict(totals),"chapter_unit_counts":dict(collections.Counter(rec["file"] for rec in originals)),
     "paragraph_outputs":originals,
    }


if __name__ == "__main__":
    record = package()
    OUTPUT.write_text(json.dumps(record,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(record["prose_counts"],record["observed_total"],len(record["paragraph_outputs"]))
