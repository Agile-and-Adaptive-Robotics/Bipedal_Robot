from collections import Counter
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
import json
import re

root = Path(__file__).resolve().parents[2]
dis = root / "Documentation/Reports and Papers/Dissertation"
notes = dis / "Notes/revision_20261117"
src = dis / "Final/chapters"
classifier = json.loads((notes / "CLASSIFIER_RESULTS.json").read_text(encoding="utf-8"))
findings = json.loads((notes / "INDEPENDENT_FINDINGS.json").read_text(encoding="utf-8"))
files = {p.name[:2]: p for p in src.glob("*.tex") if p.name[:2] in {"30","60","70","92","93","94","95","96"}}
lines = {k:p.read_text(encoding="utf-8-sig").splitlines() for k,p in files.items()}

def anchors(refs):
    result = []
    for part in refs.split():
        ch, ns = part.split(":")
        for raw in ns.split(","):
            first, sep, last = raw.partition("-")
            lo, hi = int(first), int(last) if sep else int(first)
            if ch=="95":
                # The final proof combines the two temporary-directory declarations
                # on one line. Anchor old review locations to the saved revised file.
                assert lines[ch][144].startswith("The last expression returns")
                lo -= int(lo>=132)
                hi -= int(hi>=132)
            text = "\n".join(lines[ch][lo-1:hi])
            assert text.strip(), part
            result.append(dict(file=files[ch].name, first_line=lo, last_line=hi,
                               sha256_utf8_lf=sha256(text.encode()).hexdigest(), revised_excerpt=text))
    return result

advisor_specs = {
"AD-T1": ("60:11,13", "The opening identifies the earlier AnimatLab work as a controller-development project and then credits the course project and the individual toe-joint change. The explicit controller-transfer problem names the broader research question."),
"AD-T2": ("60:7,31", "The entry defines the two-way loop, and line 31 uses the advisor's verb 'connect' for the neural command interface."),
"AD-T3": ("60:31,107,111", "The overview now says that neural outputs connect 'with actuator commands'. The following descriptions distinguish activation in the knee, the actuator command array in the bridge, and the returning mechanical measurements."),
"AD-C1": ("60:7,11,13,29", "Before discussing changes in attachment or inertia, the text defines the controller, actuator, returning measurements, and transfer task. The suspended/released observation supplies the practical context."),
"AD-C2": ("60:7,11,13", "The first sentence defines a neuromechanical simulation, the next traces the loop, and only then does the chapter explain how another body changes it. The Li, Deng, Morrow, and Bolen attribution supplies a concrete instance."),
}

independent_specs = {
"IR01": ("60:7,11,13,29", "applied_locally", "The controller, mechanical body, actuator, and sensory return are defined before the transfer. Morrow and Bolen are credited for assembling the published models. Bolen is credited for the passive toe."),
"IR02": ("60:31,46,67,77-81,98,111 95:92,94,462,464", "applied_locally", "The contribution and model tables, surrounding attribution, and appendix map link platform, authored tool, action, and verification. Preparing mechanics and exchanging arrays with an already executable model are distinct. The interface demonstration states its readback limits."),
"IR03": ("60:107,164 95:117,119,123-142,146", "applied_locally", "The closed single-joint knee provides an executable example. The commands copy all required inputs into a fresh working directory, run the fixed-condition comparison, and compare the JSON. The text specifies the pulse, input destination, returned sensory quantities, output fields, and expected result. The initial extension is attributed to the active extensor, consistent with zero flexor activation. The technical reader independently reran it."),
"IR04": ("60:211,213 95:248,250,259,261,271-275,280", "applied_locally", "Original zero of twelve averaged-channel checks, later 48 individual channel-cycle checks at nominal cadence, six adaptive replay cadences, and failed or guarded coupled trials have distinct protocols. The chronology explains why a fitted downstream output could hide a PF failure."),
"IR05": ("60:219,223,266,268 70:61,63,71 95:286,288,328,352", "applied_locally", "Assisted in-place human stepping with continuing shared drive, assisted W2L progression, W2L108 treadmill stepping, guided CAD swing clearance, and the physical balance-platform precedent are identified independently. The two W2L108 assistance windows and both sides' anatomical angles agree across files."),
"IR06": ("60:236,240,246-249,254 95:437,439,441", "applied_locally", "The separate warm W2L benchmark is in execution and provenance with its 10,000-update timed block and 5,000 preceding checks. The four Gait2392 rows identify whole process, neural calls within it, median warm updates, and a different evaluator diagnostic."),
"IR07": ("60:184 95:203,443", "applied_locally", "Archived records are described per experiment. Both the compatible retained adapter and the unavailable historical launch adapter and full command histories are identified."),
"IR08": ("95:369", "applied_locally", "A single paragraph distinguishes the incorrect adaptation outcome, including the 960-trial search, from the subsequent repeated ten-second native SCONE baseline."),
"IR09": ("92:120-127", "applied_locally", "The signed tendon-excursion moment arm is defined in metres per radian with radian measure understood, and the pose-dependent isometric-force product gives torque in newton metres. Extensor and flexor files and exact muscles are named. The more specific pose-dependent isometric force is consistent with the stored human-reference construction."),
"IR10": ("92:179-180", "applied_locally", "The force cross product is a vector. Its knee-axis projection gives the signed torque, and the planar magnitude printed by the predictor is identified as unsigned."),
"IR11": ("92:191 94:178,194,219,229-230", "applied_locally", "Source and frame conventions are identified separately for the historical two-rotation fit at both attachments and the current one-rotation standalone evaluator at both attachments. Both stiffness arrays are preserved. The reason the extra rotation can matter at the origin is stated."),
"IR12": ("94:341,351,379,381-387", "applied_locally", "The method requires ordered sagittal contacts, one crossing and monotonic release. Reverse activation is explicitly inferred from the stored sweep, circular contributions are radius times angle, and atan2 avoids subtracting separately wrapped orientations."),
"IR13": ("93:139-145,200", "applied_locally", "The text identifies the sustained alternating rhythm and missed period/cadence match. The numerical table remains specific. The paragraph describing unattempted work no longer implies 1,392 individually tuned gains."),
"IR14": ("70:53 96:20,49-50", "applied_locally", "The text identifies the actual table filter, curation record, synergist target, preparation, and phase. Ch7 distinguishes group I stimulation from isolated Ib input. The appendix presents the group-I evidence that underlies the pathway names."),
"IR15": ("96:8,10,12", "applied_locally", "Category totals sum to 1,393 and the historical retained categories sum to 957. The archive separates 382 Papers from 54 linked records in other tables. All maintenance completeness counts identify the denominator of 561 Papers."),
"IR16": ("70:84,93", "applied_locally", "The test now connects a physical embedded controller to a real-time simulation of the leg, identifies the two signal directions, and calls this controller hardware-in-the-loop. Physical valve integration is described separately."),
"IR17": ("60:211,213,260,262,266,270,274,276,282 70:49,53,57,67,71,99 96:20", "applied_locally", "SADb opens with the verified experiment. The classification disclaimer has been removed. Ch6 links each material restriction to the relevant result. Future work uses measurable perturbations and the knee-power measurement. The pathway table preserves receptor specificity."),
"IR18": ("30:26,28", "reported_outside_edit_scope", "The two Chapter 4 copyedits are listed for the author. The unrelated chapter was preserved."),
"IR19": ("92:194-198 94:217", "applied_locally", "Both derivations identify two parallel cable segments for the 10 mm assembly and six total for the 20 mm assembly. The cited predictor invokes the basic spring calculation without the optional extra wrap multiplier."),
}

def source_anchors(s):
    return [{"file":a["file"],"first_line":a["first_line"],"last_line":a["last_line"]}
            for a in anchors(s)]

directives = [
("6-opening", "Give transfer a practical high-level setting and credit predecessor work.", "60:7,11,13,29,31", "The suppressed-foot-load test and scope of joint ownership make the motivation concrete."),
("6-tools", "Distinguish created components, adaptations, prior platforms, and researcher actions.", "60:46,58-62,77-81,98,111,117 95:92,94", "The table and paragraphs identify what the researcher builds, drives, records, and compares."),
("6-example", "Give one concrete reproducible closed-loop example.", "60:107,164 95:117,119,124-142,146", "The model, actuator and sensory signals, replay command, saved output, expected quantities, and colleague's independent replay are identifiable."),
("6-chronology", "Distinguish the original syn6 PF failure, subsequent replay, and live-body results.", "60:211,213 95:248,250,259,261,271-275,280", "The original twelve channels are not equated to 48 channel-cycle checks. Coupled rhythm or knee failures remain visible."),
("6-air", "Identify BiW2Lvar+ command and sensory changes, retained records, model convention, and air-stage support.", "60:184,189,193 95:201,203,223", "The zero-to-0.15 sustained bilateral command change, two sensory configurations, original and moving-model denominators, signed knee limits, and unavailable traces are distinguished."),
("6-ground", "Separate W2L108 and CAD conditions, right/left knees, assistance denominators, and time windows.", "60:219,221,223,228 95:286,288,352", "The 29.519% positive and 35.069% signed W2L108 measures have separate windows. CAD uses engineering allocation to 54 ideal reference tensions with measured 77.5% vertical assistance and lateral/attitude guidance."),
("6-computation", "Identify the workload and timer underlying each speed comparison.", "60:236,240,246-249,254 95:437,439,441", "Each comparison states the tested network and process, neural, evaluator, or warm-update scope."),
("6-cup", "Use the 10 s 0.625 kg ramp endpoint rather than equilibrium sag.", "60:173,178 95:410", "The main and supplementary material report contemporaneous 7.85, 2.00, and 1.78 degree comparisons and define the endpoint."),
("6-drive", "Name the surviving shared descending drive under mechanical support.", "60:266 70:63 95:328", "Both chapters identify supplementary drive versus shared drive. Appendix D specifies 2.0773 nA and the separate robot result."),
("7-ends", "Distinguish the transition region from the physical end cap and verify the construction source.", "70:27,29,37", "Wall profile and cap-displacement experiments test different hypotheses. The reinforced rubber construction is attributed to the Festo datasheet. No patent is invoked."),
("7-fea", "State the FEA question, elements, contact, geometric nonlinearity, boundary conditions, and measurements.", "70:29,31,37", "Pressure loading, contraction, fixture weight, axial load, and measured displacement, profile, and reaction are specified for the proposed tests. The element choices are tied to the scale of the end transition."),
("7-routes", "Remove the new chi4 proposal and the named staggered-flexor sentence. Use pulley-assisted BPA routes.", "70:43,47,49", "The subsection retains the adopted effective stiffness and describes pulley-assisted routes and cam contact. Neither removed recommendation survives."),
("7-power", "Define instantaneous joint power and the synchronized measurement why it matters.", "70:49", "Signed torque and angular velocity about the same axis yield power in watts. The proposed dynamometer, torque sensing, encoder, pressure, and calibration explain how to measure delivery versus absorption."),
("7-sadb", "Show a verified pathway-paper-condition lookup and give the scientific finding space.", "70:53,57 96:20,49-50", "The named view, filters, paper, inhibitory and excitatory conditions, and interpretation agree with the saved app and McCrea et al. The limiting group-I selectivity belongs to the specific experiment."),
("concision", "Keep material failures and limitations with the experiment; avoid generic inventories.", "60:29,158,211,213,260,268,274,276 70:49,53,67,99 95:369", "Failed transfers, supported results, and source gaps have specific consequences; the main narrative uses them to motivate experiments."),
("other-scope", "List issues outside the permitted changes with exact location.", "30:26,28", "The bone-scans and singular-subject agreement copyedits remain documented for Ben."),
]

def split_dict(data):
    out = {}
    for line in data.strip().splitlines():
        old, new, state, reason = line.strip().split("|",3)
        out[int(old)] = (new,state,reason)
    return out

# Explicit editorial judgements from rereading both passages. A retained candidate
# remains unlabeled. None of these judgements is an observation about the advisor.
pred = {}
pred["60"] = split_dict("""
13|60:13|addressed|The joint project, individual toe, cited sources, and presentation are distinguished.
29|60:7,29,146,201|addressed|The fall has competing testable explanations. The experiment compares a specified intervention on a common clock.
31|60:31,77-81,98|addressed|Platforms and authored components are distinguished, with named scripts, operator actions, and test results.
37|60:37,42|addressed|The suggested first experiment follows an extensor sensory input to a measured motor response.
46|60:46,111,156|addressed|The two routes used to prepare mechanics are distinct from runtime exchange on the existing model.
48|60:48,236|addressed|The introductory identification of the controller is brief. The numerical implementation identity accompanies the timed trial.
67|60:67,77-81|addressed|The table describes available tools and actions. The speculative universal application no longer interrupts the result.
94|60:94,270|addressed|The measured quasi-static law is identified with the command-pressure assumption and its consequence.
107|60:107,164|addressed|A concrete loop identifies antagonist actuation, knee motion, Ia currents, and tension-derived Ib currents.
109|60:109 70:53|addressed|The author identifies what a modeled connection requires, and the database example supplies the actual source experiment.
111|60:111,156 95:94,96|addressed|The two signal directions and the update periods are tied to different identifiable tests.
115|60:115,211|addressed|The paragraph first states where in the cycle a PF channel should recruit an MN and distinguishes voltage from transmitted activity.
138|60:138,211,213|addressed|The short methods paragraph now names the two specific observables applied in the PF and load-transfer results.
142|60:142,146 95:259|addressed|The parameter search is described through candidate generation, saved outputs, and a fresh-process rerun. A concrete gain-only repair is documented in D.
144|60:144 95:344,352|addressed|The general criteria now point to the appendix for model-specific force, duration, and clearance thresholds. The CAD 80 ms threshold is correctly scoped.
146|60:146,201 95:338-344|addressed|The methods identify the varied current or removed pathways and the common condition; the worked intervention gives the actual pulse and projections.
148|60:148,236,254|addressed|The brief method identifies why neural updates and the entire trial need different timers.
157|60:154 95:76|addressed|The mean-force and negative R-squared interpretations distinguish specific muscles and name the prescribed-pose and activation boundary.
159|60:156 95:94,96|addressed|The bridge demonstrates bidirectional exchange. Saturation of the raw-length encoder is reported where the response is interpreted.
165|60:162 95:104|addressed|The result leads with ten matched bursts under shared heel input, identifies the 2 ms lag, and reports the failure without phasic heel input.
167|60:164 95:124-142,146|addressed|The result names the entry point, the command and output location, the expected transient, and links to a runnable, verified recipe.
176|60:173,178|addressed|The arm and pressure-dependent BPA20 block are identified. The response is explicitly measured at the 10 s load-ramp endpoint.
187|60:184 95:201,203|addressed|The retained adapter documents both changed conditions and makes the limit on an afference-only causal inference explicit.
196|60:193 95:223|addressed|The main paragraph gives the original weight distinction and evidence for suspended motion. D gives both force denominators and sampling windows.
198|60:195 95:227|addressed|The six trials, seeds, task, criteria, and repeat are identified. The result makes a specific claim about suspended motion.
200|60:197 95:229|addressed|The inactive-phase threshold and two perturbation times explain why the consequences were different.
204|60:201 95:338,344|addressed|Both phases and displacements appear with the same forward pulse, support, and retained weights.
214|60:211 95:248,250|addressed|A fitted downstream output hid timing that failed on all twelve channels. The principal-component descriptions remain supplementary evidence.
216|60:213 95:259,261,271-275|addressed|Failed gain-only fitting, later prescribed replay, and coupled failures are distinguished. The two denominators are explained.
218|60:215 95:150|addressed|The two reduced interventions distinguish loss of a motor burst with preserved phase from a rhythm reset.
222|60:219 95:286,288|addressed|The named W2L108 model and task, alternating swings, and both support conventions and intervals appear together.
224|60:221 95:290|addressed|The slower candidate retained swings but missed short-shuffle excursion and double-support criteria.
226|60:223,228|addressed|The author states which controller supplies timing and how 54 reference tensions are allocated before reporting the CAD outcome.
235|60:232 95:363|addressed|The three of eight perturbations that missed the predictive knee margin are clearly distinguished from the five that completed.
239|60:236,240,246-249 95:437|addressed|The paired process includes one preparation and the neural portion of those same runs. Other network and evaluator timings are separate rows.
257|60:254 95:439|addressed|The modest change in total evaluator time explains the distinction between optimizing the neural kernel and increasing full trial throughput.
263|60:260|addressed|The revised paragraph connects matched-pose testing, single-joint feedback, and measuring assistance when the walker contacts the treadmill.
265|60:262|addressed|The sensory deletion and concealed syn6 timing error identify specific measurements that would otherwise be missed.
267|60:98,107,164,282|addressed|The generic tool inventory was removed. The worked example shows how an authored model and driver reproduce a measurement.
271|60:264,266,268,270|addressed|The discussion uses specific support and force-law conditions to bound what was demonstrated on each model.
273|60:266,268|addressed|Related support conditions are compared once in the discussion, with their numerical details at the individual result.
275|60:62,270|addressed|Ideal CAD tensions isolate contact and swing demands, whereas the BPA route must generate available force at its measured length and pressure.
279|60:274 95:280|addressed|The future experiment compares timing of transmitted PF output under prescribed and coupled inputs at the corresponding knee state.
281|60:276|addressed|Identifiable force errors and matched motion or pressure histories replace the vague development phrase.
287|60:282|addressed|The closing actions now name three repeatable interventions and the conditions required to interpret them.
""")
pred["70"] = split_dict("""
6|70:6|addressed|The discussion opens with fixed-joint moment capacity and a loaded stepping task.
8|70:8|addressed|Each contribution predicts or measures a named quantity in an order a new researcher can follow.
21|70:21,25|addressed|The measured length effect and the proposed inter-batch comparison are separated.
27|70:27,31|addressed|Free, suspended-load, and fixed-separation tests identify measurements and the question each tests.
29|70:27,29,31|addressed|Transition geometry and cap compliance have different measurements. The proposed FEA cites the product datasheet and gives loading, element, and interface assumptions.
45|70:47|addressed|The exact unwanted sentence is gone. Pulley-assisted routes and cam contact have mechanical consequences and observable quantities.
47|70:43,47,49|addressed|The completed negative extra-term experiment is not proposed again.
49|70:49|addressed|The rig measures signed, synchronized torque and angular velocity and distinguishes energy delivery from absorption.
53|70:53 96:20,49-50|addressed|The reader can find the McCrea record by the actual filter, follow its DOI, and distinguish the observed effects by phase and preparation.
57|70:57|addressed|The monthly search is an implemented activity. Sign-specific preparation linkage and a second spatial browsing layout are proposed work.
59|70:53,57|addressed|The unrelated classification caveat was removed. The residual selectivity qualification directly changes physiological interpretation.
63|70:61 60:13|addressed|The originating team, published mechanics and circuit, test conditions, and justification for recording a causal signal loop are stated.
65|70:63,71 95:328|addressed|Human and W2L robot tests report separate assistance and commands. The balance-platform hardware has its own explicit attribution.
69|70:67|addressed|The next transfer test holds other conditions fixed while distinguishing rhythm reset and motor omission.
73|70:71|addressed|Trunk orientation and angular velocity, a repeated disturbance, fixed assistance, and visual drift correction define a tested comparison.
75|70:73|addressed|The proposed higher-level test specifies adaptive step length and the magnitude and persistence of the correction.
86|70:84,93|addressed|Real-time simulated leg and physical embedded controller exchange sensory measurements and actuator commands in a controller hardware-in-the-loop test.
95|70:93|addressed|The proposed sensing and valve system is related to latency from sampling to pressure response and to corrective motion.
97|70:95|addressed|Prior physical models are cited as precedents; the particular biped has a measurable comparison under the same input.
105|70:103|addressed|The conclusion distinguishes force shortfall from correctly generated but mistimed force by the observable mismatch.
""")
pred["92"] = split_dict("""
4|92:4|addressed|The author scoped the provenance claim to the mechanical model calculations in this appendix after the final reread.
79|92:79|retained_after_inspection|The constitutive distinction and two shape examples help a reader interpret the equations. The table provides symbols and values.
120|92:120-127|addressed|The revised dimensions, signed excursion, isometric-force product, data files, and muscles are correct.
159|92:151|retained_after_inspection|The source note is typographically dense but gives implementation evidence without altering the equation.
171|92:163|retained_after_inspection|The text already makes the force clamp's code location and the historical unused 40 mm coefficients explicit.
187|92:179-180|addressed|The moment vector and its signed knee-axis component are distinguished from the unsigned diagnostic.
198|92:191 94:194|addressed|The saved fit and the standalone evaluator identify their own branches and frame conventions.
205|92:198 94:217|addressed|Two and six are total parallel cable-segment counts for their respective assemblies.
""")
pred["93"] = split_dict("""
66|93:66,70|retained_after_inspection|The synapse types are described as available in the model. The following section identifies the assembled SNS population. No claim of a new demonstrated sensory pathway is made.
70|93:70|retained_after_inspection|The first sentence credits SNS-Toolbox, then identifies the 410-neuron derived circuit and its non-spiking equations.
88|93:88|retained_after_inspection|The time constant is explicitly an operating-point inheritance from the analog persistent-sodium mechanism.
112|93:112|retained_after_inspection|The block is named, the equality-at-reset failure is explained, and both voltage-coordinate frames are provided.
141|93:141,144|addressed|The main paragraph reports alternating rhythm, missed period, and different suspended cadence. The table retains the individual test clauses.
168|93:168|retained_after_inspection|The retained text gives the concrete result of leaving the old class tag: the model did not load.
200|93:200|addressed|The text identifies what was converted and excludes unattempted fits without implying individual tuning of 1,392 parameters.
205|93:205 95:104,286,332|retained_after_inspection|The 96-cell replay and its saved file are identified next to the individual cross-reference. The distinct 95-cell core and 108-cell body test retain their own identities.
""")
pred["94"] = split_dict("""
4|94:4|retained_after_inspection|The opening scopes the numeric geometry and compliance to Chapters 3 and 4 and identifies the CAD reference-point choice.
13|94:13|retained_after_inspection|The source note is dense but preserves exact transformation routines and definitions. The transformed point includes translation and rotation.
19|94:19,79|addressed|The opening now points to the appropriate extensor table. The actual test split sits with that table and its source evidence.
21|94:21|retained_after_inspection|Immediately beside the flexor data, the encoder offset and exclusion define how its retrospective value may be interpreted.
79|94:19,79|addressed|The complete extensor split is retained at the table and the earlier duplicate has been shortened.
159|94:159|retained_after_inspection|The 20 mm adjustment, 21 mm fitting, and measured versus model dimensions have different meanings and remain identifiable at the equation.
178|94:178,194|addressed|The two-rotation construction is scoped to the adoption and identified by evaluator.
194|94:194|addressed|The historical fit and current alternative implementation are separated before the origin's anisotropy is interpreted.
219|94:219,229-230|addressed|The table now cites the fitting evaluator that supplied both archived stiffness arrays.
238|94:238|retained_after_inspection|The fit constraint is wordier than necessary but makes clear that the locked pair was inherited from the flexor fit.
317|94:317,379|retained_after_inspection|The route provenance comment is secondary but the published last-active versus first-inactive pose distinction is explicit.
321|94:321|retained_after_inspection|The file sizes are incidental archive metadata in a technical appendix. They make no scientific claim.
341|94:341,387|addressed|The initial and concluding statements both specify the geometric and sweep assumptions.
351|94:351|addressed|The explanation describes avoiding subtraction of separately wrapped angles without claiming a globally unwrapped function.
379|94:379|addressed|The reverse pose is explicitly inferred from the saved forward active set.
381|94:381-385|addressed|The circular term is radius times angle and the variable-radius condyle is a length integral.
386|94:387|addressed|Any application to a second route requires one crossing, ordered sagittal contacts, supplied geometry, and monotonically releasing contacts.
""")
pred["95"] = split_dict("""
4|95:4|addressed|The appendix opens with its purpose and points directly to the two-model knee example.
36|95:34|addressed|The repaired maximum scaling and the remaining length-range issue are distinguished without introducing unrelated BPA claims.
44|95:40,45|addressed|The contact-verification paragraph and subsequent matched-pose test now have separate control questions.
81|95:76|addressed|The limit on interpreting lag is stated with the absence of historical framewise arrays and untested dynamic mechanisms.
96|95:94,96|addressed|The article identifies the runtime S-function, specific adaptations, the readbacks, and the separate model-conversion step.
102|95:100,104|addressed|Matched input conditions lead directly into the rhythm-core comparison.
106|95:104 60:162|addressed|The main chapter gives the shared burst result and lag. D includes the actual 5,000 samples and final timestamp.
131|95:150|addressed|The result identifies the PF versus RG perturbations and the two possible burst-phase outcomes.
168|95:182,286|addressed|The course-project shared RG and later bilateral design precede the comparison.
184|95:195,197,443|addressed|Calibration operations precede physical conditions. The scope of retained inputs is specified for the separate experiments.
190|95:201|addressed|The paragraph distinguishes the software selector from Hunt's published calibration procedure.
192|95:203|addressed|The retained adapter and actual missing original launch and command stream accompany the command and sensory changes.
210|95:223|addressed|One paragraph gives zero foot force, the numerator, interval, original fixed-body denominator, and alternative moving-model denominator.
216|95:229|addressed|The common 3.4 s window and the time difference for each pulse make it possible to interpret whether an output threshold was reached.
246|95:259,261|addressed|RG-triggered timing relays are described before the named native cell functions. The explicit adaptive scheduler is identified.
267|95:261,271-275,280|addressed|The conditions table distinguishes replay cadence, 30 live checks, 48 live checks, and the separately rejected physical diagnostics.
271|95:286,288,290|addressed|The paragraph distinguishes anatomical left/right knee minima and both signed/window-dependent force measures. The slower candidate has its own unmet task.
313|95:328|addressed|Shared drive remains 2.0773 nA in the supported human experiment. The robot's separate progression occurred with its own support.
320|95:334,441|addressed|The assistance paragraph covers harness force only. The W2L isolated warm update appears with timing benchmarks.
324|95:338,340,342,344,346|addressed|The common forward pulse precedes the sensor-channel, deletion, and measured contact results.
345|95:361,363|addressed|The contact controller and swing force allocation are identified. The latter paragraph then names the scope of repeat, perturbation, binary, and contact checks.
347|95:365|addressed|The matched 80% posture experiment is clearly distinguished from the later 77.5% stepping configuration.
353|95:369|addressed|The native baseline is identified as subsequently reproduced on its correct model. The earlier 960-trial transfer still failed.
393|95:408|addressed|The earlier startup measurement is explicitly differentiated from the later settled knee pulse.
425|95:437|addressed|The full 16 s trial, component time, and recorded agreement are reported together.
427|95:439|addressed|The three warm blocks and the single stage-4 evaluator have their own reference times and scope.
429|95:443|addressed|Retained currents and states are described by experiment. The missing launch and command traces are identified.
462|95:123-142,146,462,476|addressed|The executable MATLAB recipe and expected output accompany the archive directory map, with its machine-local dependencies distinguished.
""")
pred["96"] = split_dict("""
4|96:4|addressed|The appendix names the Explorer export and links the selected pathway labels to experimental evidence.
8|96:8,10,12|addressed|The five table types and historic plan-specific limit are named with the retained and archived denominators.
14|96:14,20 70:53|retained_after_inspection|The citation-graph pointer remains brief. The paper's biological mechanism is now tied to an explicitly identified experiment.
20|96:20,49-50 70:53|addressed|The named paper, dual tags and pathway associations, and linked-paper count support lookup. The chapter compares preparation, stimuli, recorded pool, and phase.
""")

observed = [dict(id=s["id"], related_issue=s["issue"], source="actual advisor "+s["category"].replace("advisor_",""),
                 original_score=s["original_score"], author=s["author"], original_anchor=dict(file=s["file"],line=s["live_line"]),
                 decision="answered_by_local_rewrite", rationale=advisor_specs[s["id"]][1],
                 revised_evidence=anchors(advisor_specs[s["id"]][0])) for s in classifier["advisor_signals"]]
ir = [dict(id=f["id"],original_location=f["location"], disposition=independent_specs[f["id"]][1],
           rationale=independent_specs[f["id"]][2],revised_evidence=anchors(independent_specs[f["id"]][0])) for f in findings]
inspections=[]
for unit in classifier["paragraph_outputs"]:
    if unit["predicted_severity"] is None:
        continue
    spec=pred[unit["file"][:2]][unit["start"]]
    inspections.append(dict(file=unit["file"], original_live_line=unit["start"], original_sha256=unit["input_sha256_utf8_lf"],
                            original_prediction=unit["predicted_severity"], advisor_label=None,
                            decision=spec[1],rationale=spec[2],revised_locations=source_anchors(spec[0])))
assert len(inspections) == sum(len(v) for v in pred.values()) == 130
assert all(s["original_score"]<0 for s in observed) and sum(s["original_score"] for s in observed)==-6
assert len(ir)==19 and len(observed)==5

oos=[
 ("OOS-30-26","30:26",-1,"based on bones scans","Change 'bones scans' to 'bone scans'.","IR18"),
 ("OOS-30-28","30:28",-1,"The intersection point of the internal crossed links define","Use 'the intersection point … defines' for subject–verb agreement.","IR18"),
 ("OOS-30-451","30:451",-3,"the OpenSim moment arm is multiplied by the muscle's maximum isometric force","State that the search reads angle-dependent exported torque targets and that the ratio of torque to signed moment arm varies with pose. A constant maximum isometric-force parameter does not reproduce either saved target. See revised Appendix A, lines 120–127, and APPENDIX_AC_E_EDITS.md, A1.","IR09; independent technical reader A1"),
]
scope=[dict(id=i,priority=s,origin="reader inspection, outside editing scope",quote=q,proposed_change=c,
            related=r,evidence=anchors(a),verdict="reported_for_author_local_source_preserved") for i,a,s,q,c,r in oos]
assert all(u["quote"] in u["evidence"][0]["revised_excerpt"] for u in scope)
result=dict(
 method="Independent semantic reread by the same GPT-6-family Codex reviewer identified in CLASSIFIER_RESULTS.json. Each of the five actual advisor signals was reread separately. Each IR finding and each of the 130 earlier flagged unlabeled passages was compared with the revised source in its own context. File and line anchors below are one-based. No score is imputed to the advisor for an unmarked passage.",
 date_utc=datetime.now(timezone.utc).isoformat(),
 manuscript_root=str(src), original_classification="CLASSIFIER_RESULTS.json",
 pre_edit_finding_table="INDEPENDENT_FINDINGS.json",
 source_sha256={p.name:sha256(p.read_bytes()).hexdigest() for k,p in files.items()},
 original_advisor_signals=observed,observed_total=-6, observed_issue_groups=["context","interface"],
 independent_findings=ir, out_of_scope=scope,
 manuscript_directive_checks=[dict(id=i,request=r,revised_locations=source_anchors(a),judgement=j) for i,r,a,j in directives],
 followup_findings=[
    dict(id="RR01",source="Independent reread",location="60-sns.tex:164",original_intermediate="Excitation of the extensor MN and reciprocal inhibition of the flexor MN change the opposing moments at the knee.",
         disposition="applied_locally",judgement="The measured flexor was already inactive. The corrected account attributes the initial motion to the rise in extensor force.",evidence=anchors("60:164 95:119")),
    dict(id="RR02",source="Independent reread, IR16",location="70-overall.tex:84",original_intermediate="A computer-in-the-loop experiment would send the sensor signals generated by the simulated leg to the embedded controller and return its actuator commands to the model.",
         disposition="applied_locally",judgement="The real-time test now explicitly uses a physical embedded controller and is named controller hardware-in-the-loop.",evidence=anchors("70:84")),
    dict(id="RR03",source="Independent reread, IR17",location="96-AppendixE.tex:20",original_intermediate="The same stimulus inhibited this synergist pool at rest and excited it during the extensor phase of fictive locomotion evoked by midbrain stimulation.",
         disposition="applied_locally",judgement="The detailed comparison now appears once in the Chapter 7 narrative. Appendix E supplies the six Papers, both afferent tags, and dual pathway lookup needed to verify it.", evidence=anchors("70:53 96:20,49-50")),
    dict(id="RR04",source="Independent reader, originally unlabeled prose",location="92-AppendixA.tex:4 and 94-AppendixC.tex:19",original_intermediate="any number in this dissertation; the adopted fit trained on {5, 6, 7} and used tests 1, 2, and 8 for validation",
         disposition="applied_locally",judgement="The appendix-level traceability claim was scoped and the doubled extensor split was replaced by a table pointer while retaining its sources.",evidence=anchors("92:4 94:19,79")),
    dict(id="RR05",source="Independent reader, 2021 primary poster",location="60-sns.tex:13",original_intermediate="We adjusted currents, synaptic weights, and muscle parameters by hand and presented the suspended model at the NIH BRAIN Initiative Investigators Meeting",
         disposition="applied_locally",judgement="The course project is credited to Morrow and Bolen, the individual toe addition to Bolen, and the publication to Hunt and Bolen. The revised text says they reported it in a poster, avoiding an unsupported identification of the physical presenter.",
         primary_source="Documentation/Posters/4008_Bolen_Ben_PDF.pdf",primary_sha256="6698593d938670e7b6daa71011d9906dc0c36439f0dc81d10c09e87497fa3d93",verified_byline="Ben Bolen, Alexander Hunt",evidence=anchors("60:13")),
    dict(id="RR06",source="Independent reader, rendered manuscript",location="build_r2 Chapter 6 printed pp. 137–139 and 146–152",original_intermediate="p. 146 ended 'in the afferented condition, the'; three full figure pages intervened before p. 150 continued 'suspension carried'. A later text page carried only five lines before Fig. 6.7.",
         disposition="applied_locally",judgement="The two model and tool introductions now share their respective table pages. The result figures appear between complete paragraphs. In the combined proof p. 151 contains the phase-specific pulse and the complete W2L sensory comparison ahead of Fig. 6.7 on p. 152.",evidence=source_anchors("60:48,65,67,84,181,196,201,211,213,223,232,236")),
    dict(id="RR07",source="Retained original figure information, independent visual check",location="60-sns.tex:206 / Figure 6.7",original_intermediate="RG voltages, joint angles, and heel normal forces show how joint cycling can persist after bilateral contact timing changes.",
         disposition="applied_locally",judgement="The caption now distinguishes the visible 12–15 s from the 4.5 ≤ t < 30 s contact-phase calculation. Solid lines denote the left leg and dashed lines the right in both panels.",
         primary_source="Documentation/Reports and Papers/Dissertation/Figures/60-sns/w2l_feedback_short_20261031_alt.txt",evidence=anchors("60:206 95:344")),
 ],
 predicted_passage_decisions=dict(Counter(i["decision"] for i in inspections)), predicted_passage_reread=inspections,
 coverage="All seven original target sources and all seven rewritten sources read. The 136 originally unlabeled passages without a prediction stay unlabeled. The other two narrative units contain actual advisor feedback and were evaluated separately above. Logistical checks, defense slide provenance, author acceptance, and publication remain with their designated reports.",
)
proof=root/"tmp/dissertation_revision_20261117/build_r4/main.pdf"
before_layout=Path(__file__).resolve().with_name("before_float_layout_60.tex").read_text(encoding="utf-8-sig")
after_layout=files["60"].read_text(encoding="utf-8-sig")
def normalize_placement(text):
    text = re.sub(r"(\\begin\{(?:table|figure)\})\[[!Hhtbp]+\]",r"\1",text)
    text = text.replace(r"\noindent\begin{minipage}{\linewidth}","").replace(r"\end{table}\end{minipage}",r"\end{table}")
    text = text.replace(r"{\interlinepenalty=10000 ","").replace(r"\par}","")
    return [l for l in text.splitlines() if l.strip() and l.strip()!=r"\FloatBarrier"]
a,b=normalize_placement(before_layout),normalize_placement(after_layout)
assert len(a)==len(b)
diff_lines=[(x,y) for x,y in zip(a,b) if x!=y]
assert len(diff_lines)==2 and "For a course project" in diff_lines[0][0] and "W2L sensory-pathway removal" in diff_lines[1][0]
assert re.findall(r"\\includegraphics\[[^\]]+\]\{[^}]+\}",before_layout)==re.findall(r"\\includegraphics\[[^\]]+\]\{[^}]+\}",after_layout)
result["visual_review"] = dict(
    pdf=str(proof),sha256=sha256(proof.read_bytes()).hexdigest(),pages=313,
    checked="All 27 Chapter 6 pages, printed 133–159 (physical PDF pages 153–179), rendered through Poppler at 120 dpi. All four tables and eight figures were checked in sequence on the combined r3 proof. Table 6.2 and Figure 6.7 were additionally reopened as individual full-page images. Rendering the same 27 pages from the delivered r4 PDF produced 27 byte-identical full-page PNGs. Two Chapter 7 figure placement specifiers were the only source changes between those proofs.",
    artifacts=dict(table_pages={"6.1":137,"6.2":138,"6.3":143,"6.4":156},figure_pages={"6.1":134,"6.2":136,"6.3":141,"6.4":147,"6.5":148,"6.6":150,"6.7":152,"6.8":155}),
    measurements="Vector labels on Figures 6.2–6.7 have minimum plotted horizontal font sizes of 10.50, 10.00, 10.00, 10.00, 10.00, and 11.61 PDF points, respectively, rounded to 0.01. Chapter 6 table text is 10.91 PDF points. Figure 6.1 uses 11.96-point TeX panel labels around two original images, and Fig. 6.8 is an original raster CAD view whose embedded letter size is not encoded as a vector font. The CAD image spans 449.65 PDF points and its two view labels are legible in the final render.",
    verdict="The two contribution tables now stay with their introductions. The complete knee/cup comparison precedes Figures 6.4 and 6.5. Figures 6.6, 6.7, and 6.8 fall between complete result paragraphs without the former five-line page. All captions, letters, axes, and table rows remain visible within the page. The seven files' stored source hashes were refreshed against this combined proof.",
    conservation="Comparing Chapter 6 immediately before and after the independent layout work preserves every includegraphics filename and size option, and every line of manuscript content except the separately documented 2021 poster byline and Figure 6.7 caption corrections.")
outfile=notes/"INDEPENDENT_REREAD.json"
temp=outfile.with_name(outfile.name+".new")
temp.write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
temp.replace(outfile)
print(f"Saved {len(observed)} actual advisor signals, {len(ir)} findings, {len(inspections)} predicted rereads and {len(scope)} outside-scope issues to {outfile.name}")
