from difflib import SequenceMatcher
from pathlib import Path
from collections import Counter
from math import log, sqrt
import json
import re
import sys

root = Path(__file__).resolve().parents[2]
dis = root / "Documentation/Reports and Papers/Dissertation"
capture = root / "tmp/dissertation_revision_20261117/live"
src = dis / "Final/chapters"
notes = dis / "Notes/revision_20261117"
classification = json.loads((notes / "CLASSIFIER_RESULTS.json").read_text(encoding="utf-8"))
def read(path):
    return path.read_text(encoding="utf-8-sig").splitlines()
def words(s):
    return Counter(re.findall(r"[a-z][a-z0-9_-]+|[0-9][.0-9]*", s.lower()))
def report(file):
    original, revised = read(capture / file), read(src / file)
    aligned = {}
    for i, j, n in SequenceMatcher(None, original, revised, autojunk=False).get_matching_blocks():
        for k in range(n):
            aligned[i+k+1] = j+k+1
    revised_words = [(i+1,words(s)) for i,s in enumerate(revised) if len(s)>34 and not s.startswith("%")]
    df = Counter(w for _,rw in revised_words for w in rw)
    wt = {w:log(1+len(revised_words)/d)**2 for w,d in df.items()}
    for unit in classification["paragraph_outputs"]:
        if unit["file"] != file or not unit["predicted_severity"]:
            continue
        ix = unit["start"]
        ow = words(unit["input"])
        normo = sqrt(sum(wt.get(w,1)*x*x for w,x in ow.items()))
        scores=[]
        for ir,rw in revised_words:
            normr = sqrt(sum(wt.get(w,1)*x*x for w,x in rw.items()))
            sim = sum(wt.get(w,1)*rw[w]*x for w,x in ow.items())/(normo*normr)
            scores.append((sim,ir))
        scores.sort(reverse=True)
        best = aligned.get(ix, scores[0][1])
        line = revised[best-1]
        print(f"{ix:3} {'=' if ix in aligned else '~'} {best:3}   {line[:113]}")
if __name__ == "__main__":
    for n in sys.argv[1:]:
        f=next(x for x in classification["chapter_unit_counts"] if x.startswith(n))
        print(f)
        report(f)
