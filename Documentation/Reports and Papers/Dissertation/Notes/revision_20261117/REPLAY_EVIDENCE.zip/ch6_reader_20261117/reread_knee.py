from pathlib import Path
from scipy.io import loadmat
import numpy as np
root = Path(__file__).resolve().parent
a=loadmat(root/'knee/results/probe/reader_summary.mat')
t=a['t'].ravel()
mask=t>=30
for i,name in enumerate(('q','qd','Vext','Vflex','Aext','Aflex','Fext','Fflex','stim')):
    c=a['C'][mask,i]
    p=a['P'][mask,i]
    print(name, 'control range',c.min(),c.max(),'pulse range',p.min(),p.max(),'max abs difference',abs(c-p).max())
for i,name in ((4,'Aext'),(5,'Aflex'),(6,'Fext'),(7,'Fflex')):
    for start,end in ((30,30.030),(30.030,30.111),(30.111,30.250)):
        included=(t>=start)&(t<=end)
        z=a['P'][included,i]
        print(name,start,end,'min,max',z.min(),z.max())
    print(name,'first sample above 0.001',t[mask][np.where(a['P'][mask,i]>0.001)[0][0]])
