from pathlib import Path
from collections import Counter
import json
import numpy as np
from scipy.io import loadmat, whosmat

root = Path(__file__).resolve().parents[2]
for group in ('Vasti','Bifem'):
    folder=root/'Testing_Data/2022_02_Festo'
    af=np.loadtxt(folder/f'OpenSim_{group}_MomentArm.txt',skiprows=7)
    tf=np.loadtxt(folder/f'OpenSim_{group}_Results.txt',skiprows=7)
    arm,torque=af[:,2:],tf[:,2:]
    print('torque/arm',group, np.nanmin(torque/arm,axis=0),np.nanmax(torque/arm,axis=0))
    print('shape, max angular mismatch deg, and first record',group,af.shape,max(abs(af[:,1]-tf[:,1])),tf[0,1],arm[0,-1],torque[0,-1])
flex = root / 'Testing_Data/2022_02_Festo/minimizeFlxPin10_results.mat'
fields = loadmat(flex, variable_names=['TRANSMODE', 'USE_BRACKET2', 'TAG', 'filtered_results', 'xCols'], simplify_cells=True)
row = fields['filtered_results'][76]
print('fit', fields['TRANSMODE'], fields['USE_BRACKET2'], fields['TAG'], row[1:3], row[np.asarray(fields['xCols'],int)-1])
ext = root / 'Code/Matlab/Mesh_Optimization/Results/Vas_Pam_20mm_Result_20260925.mat'
def visit(obj,path='',depth=0):
    if not isinstance(obj,dict) or depth==4:
        return
    for k,v in obj.items():
        if k.lower() in ['eliminatedangled','wrap','geometricwrap','wrapinfo']:
            print(path+k,list(v)[:35] if isinstance(v,dict) else np.shape(v))
        if isinstance(v,dict) and 'radius' in v and 'angleRad' in v and 'length' in v:
            a,r,l = (np.asarray(v[field]) for field in ('angleRad','radius','length'))
            delta=np.abs(a*r-l)
            ix=np.nanargmax(delta[2])
            print('wrap lengths',np.shape(a),np.nanmax(delta,axis=1),np.nanmax(l,axis=1),v['labels'])
            print('condyle maximum discrepancy at pose',ix+1,'R,alpha,stored length,difference',r[2,ix],a[2,ix],l[2,ix],delta[2,ix])
        visit(v,path+k+'.',depth+1)
saved=loadmat(ext,variable_names=['routeInfo','mech','mechP','best','result','bendMeasure','wrapInfo','route','pred','ctx','opt'],simplify_cells=True)
print('named route variables',sorted(saved))
visit(saved)
data=json.loads((root/'SADb_audit/export/sadb_export.json').read_bytes())
print('records',len(data),Counter((r['recordType'],r.get('archived',False)) for r in data))
papers = [r for r in data if r['recordType']=='paper']
kept = [r for r in papers if not r.get('archived',False)]
print('coverage', {k:sum(bool(r[k]) for r in kept) for k in ['notes','has_notes','animals','animal_study','feedback','afferents','robot_sim','doi']},'all-links',sum(len(r['feedback']) for r in kept))
for field in ['Ia monosynaptic excitation','Ia reciprocal inhibition','Ib disynaptic inhibition','Ib disynaptic excitation','Ib stance to swing','Ia or II stance to swing','type II excitatory','Cutaneous flexor excitation']:
    print('links',field,[sum(field.casefold() in [t.casefold() for t in r['feedback']] for r in p) for p in (papers,kept)])
for r in data:
    if r['id'] in ['recznPoxFR6AVN36u','recBMsJS4yKuHNuo5']:
        print('link record',r['id'],r['title'],r['afferents'],r['feedback'])
