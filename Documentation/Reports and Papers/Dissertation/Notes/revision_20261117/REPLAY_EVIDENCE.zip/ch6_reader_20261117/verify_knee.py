"""Compare the fresh MATLAB output with retained control, pulse, and fine-step arrays."""
from pathlib import Path
import hashlib
import json
import numpy as np
from scipy.io import loadmat

scratch = Path(__file__).resolve().parent
source = scratch.parents[1] / "Code/Matlab/SNS_Simscape/results/knee_transient_reflex_20261028"
out = scratch / "knee/results/probe"
fresh = loadmat(out / "reader_summary.mat")
reference = loadmat(source / "replay_summary.mat")
arrays = {}
for key in ("t", "C", "P", "F"):
    a, b = fresh[key], reference[key]
    arrays[key] = dict(shape=a.shape, dtype=str(a.dtype), bytes_equal=a.shape==b.shape and a.dtype==b.dtype and a.tobytes()==b.tobytes(),
                       maximum_difference=float(np.max(np.abs(a-b))))
def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
result = dict(arrays=arrays,
              inputs={str(p.relative_to(source)):digest(p) for p in (source/"run_transient.m",source/"original_snapshot/KneeReflexDemo.slx",source/"original_snapshot/SNS_Library.slx")},
              json_sha256=digest(out/"reader_summary.json"),reference_json_sha256=digest(source/"replay_summary.json"))
(scratch/"knee_comparison.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
print(json.dumps(result,indent=2))
