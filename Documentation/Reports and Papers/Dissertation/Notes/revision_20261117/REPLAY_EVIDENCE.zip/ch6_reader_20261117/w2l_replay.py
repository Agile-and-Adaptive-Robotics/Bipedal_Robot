"""Rerun one archived W2L job in an isolated output directory and observe actual sensory inputs."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import sys

parser = argparse.ArgumentParser()
parser.add_argument("condition", choices=("panel_control", "panel_del_all_feedback", "panel_del_Ib"))
options = parser.parse_args()
sys.argv = [sys.argv[0]]  # Historical ground/air modules parse arguments on import.
out = Path(__file__).resolve().parent / options.condition
out.mkdir(parents=True, exist_ok=True)
spinal = Path(__file__).resolve().parents[2] / "Code/MuJoCo_SNS/spinal"
source = spinal / "reports_20261027_codex"
for setting in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[setting] = "1"
os.environ["CONDA_PREFIX"] = str(Path(sys.executable).parent)
sys.path[:0] = [str(spinal / "w2l_mujoco"), str(spinal / "w2l_cpg")]
import numpy as np
import mujoco
import test_w2l_air  # ground imports this module; both wrap sys.stdout during import.
air_stdout = sys.stdout  # Keep the first wrapper alive while ground takes a second view.
import test_w2l_ground as ground
import build_w2l_net as circuits

# The evaluator regenerates its ground XML on import. Keep that copy with the output.
ground.GROUND = str(out / "w2l_ground.xml")
spec = importlib.util.spec_from_file_location("reader_w2l_recovery", source / "recover_w2l.py")
recovery = importlib.util.module_from_spec(spec)
spec.loader.exec_module(recovery)
recovery.HERE = out  # Only the destination. SPINAL retains its normal source location.

force_min, force_max = np.inf, -np.inf
neural_inputs = []
port_names = []
readings = 0
original_mj_step, original_neural_step = mujoco.mj_step, circuits.W2LNet.step

def observe_force(m, d):
    global force_min, force_max, readings
    force_min = min(force_min, float(d.actuator_force.min()))
    force_max = max(force_max, float(d.actuator_force.max()))
    readings += 1
    return original_mj_step(m, d)

def observe_inputs(network, applied):
    if not port_names:
        port_names.extend(network.inputs)
    neural_inputs.append(applied.copy())
    return original_neural_step(network, applied)

mujoco.mj_step = observe_force
circuits.W2LNet.step = observe_inputs
try:
    recovery.one(source / (options.condition + "_input.json"))
finally:
    mujoco.mj_step = original_mj_step
    circuits.W2LNet.step = original_neural_step

applied = np.array(neural_inputs)
np.savez_compressed(out / "observed_inputs.npz", names=np.array(port_names), inputs_nA=applied)
numeric_equal = {}
with np.load(out / (options.condition + ".npz"), allow_pickle=False) as actual:
    with np.load(source / (options.condition + ".npz"), allow_pickle=False) as saved:
        for key in actual.files:
            if key != "fall_t" and np.issubdtype(actual[key].dtype, np.number):
                numeric_equal[key] = bool(np.array_equal(actual[key], saved[key], equal_nan=True))
metrics = json.loads((out / (options.condition + ".json")).read_text())["metrics"]
observation = dict(
    python=sys.version.split()[0],
    numpy=np.__version__,
    mujoco=mujoco.__version__,
    original_job=str(source / (options.condition + "_input.json")),
    original_ground_xml_matches=(out / "w2l_ground.xml").read_bytes() == (spinal / "w2l_mujoco/w2l_ground.xml").read_bytes(),
    samples_physics=readings,
    actuator_force_range_N=[force_min, force_max],
    samples_neural=len(applied),
    ports={name: [float(applied[:, i].min()), float(applied[:, i].max())] for i, name in enumerate(port_names)},
    numeric_trajectory_equal=numeric_equal,
    metrics={k: metrics[k] for k in ("cycL", "cycR", "phase_med", "fwd", "survive", "finite", "fall", "phase_n", "wall_s")},
)
(out / "reader_observations.json").write_text(json.dumps(observation, indent=2), encoding="utf-8")
print(json.dumps(observation, indent=2))
