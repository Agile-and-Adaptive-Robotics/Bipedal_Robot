"""Independent bounded checks of the retained Chapter 6 recordings."""
from pathlib import Path
import csv
import json
import sys
import numpy as np

scratch = Path(__file__).resolve().parent
repo = scratch.parents[1]
spinal = repo / "Code/MuJoCo_SNS/spinal"
sys.path[:0] = [str(spinal), str(spinal / "controller_profiles_20261104")]
import dominant_cycles
import kine_ref

raw = Path("D:/Users/Ben Bolen")
data = {}
for stage in (1, 2):
    body = raw / "ControllerTraining_20261104/hunt_pose_air_validation_v3" / f"stage{stage}"
    with np.load(body / "capture/aligned_trace.npz") as z:
        t = z["t_state"]
        names = z["joint_names"].tolist()
        q = np.degrees(z["qpos"][:, z["joint_qpos_addresses"]])
        knees = q[:, [names.index("knee_angle_" + side) for side in ("r", "l")]]
        hips = q[:, [names.index("hip_flexion_" + side) for side in ("r", "l")]]
        mask = (t >= 5) & (t < 14)
        check = dominant_cycles.measure(t[mask], -knees[mask], hips[mask])
        result = dict(
            score_window=[float(t[mask][0]), float(t[mask][-1])],
            peaks=check["principal_peak_times_s"],
            complete_ipsilateral_intervals=[len(x) - 1 for x in check["principal_peak_times_s"]],
            period_s=check["period_s"], phase_error=check["bilateral_phase_error"],
            full_max_knees_deg=knees.max(axis=0).tolist(),
            foot_force_max_N=float(np.max(abs(z["foot_force_anatomical_N"]))),
        )
    with np.load(body / "body.assistance.npz") as z:
        samples=z["samples"]; window=samples[:,0]>=5
        force=float(samples[window,1].mean())
        result.update(support_mean_N=force,legacy_percent=force/(78.4646*9.81)*100,moving_percent=force/(78.3646*9.81)*100)
    data[f"air{stage}"] = result

cad = raw / "CAD3DOF_20261102/contact_handover_20261103/runs/clearance77p5_damped.npz"
with np.load(cad) as z:
    t = z["time"]; mask = (t>=16) & (t<28)
    loads=z["contact_loads"].sum(axis=2)
    events=[]
    for side in range(2):
        ok=mask & (z["mesh_clearance"][:,side]>.005) & (loads[:,side]<7.36) & (loads[:,1-side]>15)
        runs=np.flatnonzero(np.diff(np.r_[False,ok,False].astype(int))).reshape(-1,2)
        events.extend((float(t[start]),side) for start,end in runs if t[end-1]-t[start]>=.08)
    events.sort()
    counts=[sum(s==side for _,s in events) for side in (0,1)]
    data["cad"]=dict(window=[float(t[mask][0]),float(t[mask][-1])],samples=int(mask.sum()),counts_RL=counts,
                     alternations=sum(a[1]!=b[1] for a,b in zip(events,events[1:])),force_N=float(z["rig_force"][mask,1].mean()),
                     signed_world_forward_displacement_m=float(z["qpos"][-1,0]-z["qpos"][0,0]),captured_knee_min_anatomical_deg=(-np.degrees(z["knee_coordinate"].max(axis=0))).tolist())
    data["cad"]["every_2ms_knee_min_anatomical_deg"]=(-np.degrees(json.loads(cad.with_suffix(".json").read_text())["max_knee_every_physics_step_rad"])).tolist()

ground = raw / "NeuroCampaign_20261031/LiDeng_W2L_20261104"
wf = json.loads((ground / "FRESH_VERIFICATION.json").read_text())
model = ground / "fresh_repeat/W2L_VirtualWalker_Newer/repeat/trajectory.npz"
with np.load(model) as z:
    t=z["t"]; mask=(t>=1)&(t<10)
    weight=float(wf["result"]["robot_mass_kg"]*9.81)
    axes=[z[key][:,1] for key in ("rail_force_world","guide_force_world","harness_force")]
    origin = next(p for p in (ground / "body_trials/W2L_VirtualWalker_Newer").glob("*trial_0010_*/trajectory.npz"))
    with np.load(origin) as saved:
        eq={k:bool(z[k].dtype==saved[k].dtype and z[k].shape==saved[k].shape and z[k].tobytes()==saved[k].tobytes()) for k in z.files if np.issubdtype(z[k].dtype,np.number)}
    data["W2L108"]=dict(scored_time=[float(t[mask][0]),float(t[mask][-1])],weight_N=weight,upper_only_percent=100*sum(np.maximum(a[mask],0).mean() for a in axes)/weight,
                        signed_whole_percent=100*sum(a.mean() for a in axes)/weight,number_numeric_equal=sum(eq.values()),number_numeric=len(eq))

for label, path in [
    ("historical_human", spinal / "reports_20261028_publication_flow/human_ik/human_fresh.npz"),
    ("graded", spinal / "spinal_run_spkbase_s3k.npz"),
    ("spiking", spinal / "spinal_run_spkbase_spiking.npz"),
]:
    with np.load(path,allow_pickle=False) as z:
        valid=np.r_[True,z["t"][1:]>0]
        t,q,v,F=(z[k][valid] for k in ("t","q","neuro","contact"))
        check=kine_ref.compare(t,q,v,2.,contact=F)
        mask=t>=2.
        data[label]=dict(kine_score=check["kine_score"],score_start_s=float(t[mask][0]),score_end_sample_s=float(t[mask][-1]),
                         contact_gt20N=(F[mask]>20).mean(axis=0).tolist(),cycles_RL=[kine_ref.sim_side(t,q,v,2.,s,F)[5] for s in ("r","l")])

with (spinal / "muscle_force_compare.csv").open(newline="") as f:
    reader=csv.reader(f); next(reader)
    stats={r[0]:[float(r[1]),float(r[4])] for r in reader}
    data["right_side_force"]=dict(passed=[m for m,(r,ratio) in stats.items() if .87<=r<=.98 and abs(ratio-1)<=.10],others={m:[r,ratio] for m,(r,ratio) in stats.items() if not (.87<=r<=.98 and abs(ratio-1)<=.10)})
(scratch/"record_checks.json").write_text(json.dumps(data,indent=2),encoding="utf-8")
print(json.dumps(data,indent=2))
