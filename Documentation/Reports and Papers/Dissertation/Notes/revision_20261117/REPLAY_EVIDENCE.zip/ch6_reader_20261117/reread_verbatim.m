s = fullfile(pwd,'Code','Matlab','SNS_Simscape','results');
s = fullfile(s,'knee_transient_reflex_20261028');
b = fullfile(s,'original_snapshot');
w = tempname;
d = fullfile(w,'demos');
p = fullfile(w,'results','knee');
mkdir(d); mkdir(p);
copyfile(fullfile(b,'SNS_Library.slx'),w);
copyfile(fullfile(b,'KneeReflexDemo.slx'),d);
copyfile(fullfile(s,'run_transient.m'),p);
addpath(p);
run_transient('reader');
m = jsondecode(fileread(fullfile(p,'reader_summary.json')));
ref = jsondecode(fileread(fullfile(s,'replay_summary.json')));
isequaln(m,ref)
assert(isequaln(m,ref));
disp('PRINTED EXAMPLE PASSED');
disp(w);
disp(m.paper_extension_excursion_deg);
