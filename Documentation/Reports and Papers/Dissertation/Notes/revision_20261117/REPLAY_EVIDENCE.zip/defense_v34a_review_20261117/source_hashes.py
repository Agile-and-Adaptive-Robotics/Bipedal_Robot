import hashlib
import json
import os
import socket
import subprocess
from pathlib import Path

repo = Path(r'D:\Github\Bipedal_Robot')
raw = Path(r'D:\Users\Ben Bolen')
spinal = repo/'Code/MuJoCo_SNS/spinal'
hand = repo/'Documentation/Reports and Papers/Dissertation/Defense/Session1_Handoff_20261104'
knee = repo/'Code/Matlab/SNS_Simscape/results/knee_transient_reflex_20261028'
bridge = repo/'Code/Matlab/SNS_Simscape/mujoco_bridge'
training = raw/'ControllerTraining_20261104'
lideng = raw/'NeuroCampaign_20261031/LiDeng_W2L_20261104'
accel = raw/'NeuroAcceleration_20261104'
historical = raw/'NeuroCampaign_20261102_9h'
tools = raw/'ToolchainDefense_20261102/other_models'
cad = raw/'CAD3DOF_20261102/contact_handover_20261103'

groups = [
    ('Portable source / media', hand, [
        'START_HERE.md', 'docs/TOOLCHAIN_EVIDENCE_INVENTORY.md', 'media/W2L108_graded_39p24pctBW.gif',
        'media/Gait2392_Hunt_PT_RC_48p85pctBW.gif', 'media/CAD_reference_tension_77p5pctBW.gif',
        'records/GAIT_SUPPORT_DECOMPOSITION_5_TO_13.json','records/NEURAL_ACCELERATION_20261104.md',
        'experiments_20261104/GAIT_AIR_VALIDATION.json','experiments_20261104/LiDeng_W2L108_RESULT.md',
        'experiments_20261104/LiDeng_W2L108_ground.gif','experiments_20261104/s3k_syn6_followup/syn6_ankle_corrected/FRESH_REPEAT_AUDIT.json',
        'experiments_20261104/s3k_syn6_followup/syn6_ankle_corrected/ANKLE_SPECTRA.json',
        'experiments_20261104/circuit_trace_20261105/syn6/timing_audit/PF_TIMING_AUDIT.json']),
    ('Implementation / replay', repo, [
        'Neuromechanical_Models/W2L_VirtualWalker_Newer_20261031/W2L_VirtualWalker_Newer_Standalone.asim',
        'Code/Matlab/SNS_Simscape/demos/sns_build_demo.m','Code/Matlab/SNS_Simscape/demos/sns_build_beer_demo.m',
        'Code/Matlab/SNS_Simscape/mujoco_bridge/BRIDGE_REPORT.md','Code/Matlab/SNS_Simscape/mujoco_bridge/matlab/run_bridge_tests.m',
        'Code/MuJoCo_SNS/spinal/w2l_cpg/sparse_pairwise_eval.py','Code/MuJoCo_SNS/spinal/w2l_cpg/compact_pairwise_eval.py',
        'Code/MuJoCo_SNS/spinal/controller_profiles_20261104/body_probe.py','Code/MuJoCo_SNS/spinal/reports_20261027_codex/full_basin_results.json',
        'Code/MuJoCo_SNS/spinal/reports_20261027_codex/benchmark_exact.json','Code/MuJoCo_SNS/spinal/reports_20261027_codex/w2l_verified_config.json',
        'Code/MuJoCo_SNS/spinal/reports_20261027_codex/trial458_d30.npz','Code/MuJoCo_SNS/spinal/reports_20261027_codex/panel_control.npz',
        'Code/MuJoCo_SNS/spinal/reports_20261027_codex/panel_del_all_feedback.npz','Code/MuJoCo_SNS/spinal/wean_tune_20261016.py',
        'Code/MuJoCo_SNS/spinal/reports_20261027_codex/verification.json','Code/Matlab/SNS_Simscape/results/SNS_W2L_CPG.slx']),
    ('Knee transient', knee, ['run_transient.m','replay_summary.json','replay_summary.mat']),
    ('Training raw', training, ['EXPERIMENT_RECORD.md','source_snapshot_final/controller_profiles_20261104/body_probe.py','hunt_pose_air_validation_v3/COMPLETE.json',
        'hunt_pose_air_validation_v3/stage2/body.json','hunt_pose_air_validation_v3/stage2/SOURCE.json',
        'hunt_pose_air_validation_v3/stage2/capture/model.mjb','hunt_pose_air_validation_v3/stage2/capture/aligned_trace.npz',
        'syn6_ankle_selected_repeat_20261104/COMPLETE.json','syn6_ankle_selected_repeat_20261104/stage2/body.json',
        'syn6_ankle_selected_repeat_20261104/stage2/body.npz','syn6_ankle_selected_repeat_20261104/stage2/capture/model.mjb',
        'syn6_flexor_handover_20261105/predict150_live_timing/TIMING.json','syn6_flexor_handover_20261105/predict150_stage2/body.json',
        'source_snapshot_pf_design_20261105/pf_timing_audit.py','waveform_edge_D_20261104/syn6/BEST_TRACE.npz',
        'syn6_native_20261105_v7/final_verified/TIMING.json','syn6_adaptive_20261105/replay/TIMING.json',
        'syn6_adaptive_20261105/replay_live_range/TIMING.json','syn6_adaptive_20261105/live_full_native/TIMING.json']),
    ('Li-Deng calibrated ground raw', lideng, ['EXPERIMENT_RECORD.md','ADAPTER_SOURCE.py','BEST.json','LAUNCH.json','FRESH_VERIFICATION.json',
        'fresh_repeat/W2L_VirtualWalker_Newer/repeat/model.xml','fresh_repeat/W2L_VirtualWalker_Newer/repeat/trajectory.npz',
        'fresh_repeat/W2L_VirtualWalker_Newer/repeat/SUPPORTED_STEPPING_REPLAY.gif','fresh_repeat/W2L_VirtualWalker_Newer/repeat/ASSESSMENT.json']),
    ('Compact acceleration raw', accel, ['EXPERIMENT_RECORD.md','results/KERNEL_BENCHMARK_hunt.json','results/VERIFIED_SUMMARY.json',
        'source/benchmark.py','body/FINAL_BACKEND_PROFILE.json','body/compact_final.json','body/sparse_final.json']),
    ('Earlier source-process timing raw', historical, [
        'timings/source_native_s1/RESULT.json','timings/source_baseline_s1/RESULT.json',
        'configurations/source_native_s1.json','configurations/source_baseline_s1.json',
        'figures/stage5_contact_strength_review/COMPARISON.json','figures/FINAL_RC_FRESH_HASH_CHECK.json',
        'EXPERIMENT_RECORD.md']),
    ('Defense conditions raw', tools, ['MODEL_REPLAY_MANIFEST.json',
        'gait_hunt_rc/capture/aligned_trace.npz','gait_hunt_rc/capture/model.mjb',
        'w2l108_graded/W2L_VirtualWalker_Newer/fresh_graded_ground/RESULT.json',
        'w2l108_graded/W2L_VirtualWalker_Newer/fresh_graded_ground/trajectory.npz',
        'w2l108_graded/W2L_VirtualWalker_Newer/fresh_graded_ground/SUPPORTED_STEPPING_REPLAY.gif']),
    ('CAD contact handover raw', cad, ['SELECTED_CONDITION.json','FINAL_VERIFICATION.json','FINAL_CHECKS.json']),
    ('Editable W2L subnetworks', raw/'NeuroCampaign_20261031/subnetworks/W2L108_verified',
        ['FUNCTIONAL_SUBNETWORK_VERIFICATION.json','SOURCE_MANIFEST.json','editable/W2L_VirtualWalker_Newer_Standalone.asim']),
    ('Desktop deck evidence', raw/'NeuroGraphics_20261104/deck_v29b/build',
        ['schematic_manifest.json','author_schematics.mjs','delivery.json']),
]


def get_git():
    from shutil import which
    if which('git'):
        return which('git')
    options = sorted((Path(os.environ['LOCALAPPDATA']) / 'GitHubDesktop').glob('app-*/resources/app/git/cmd/git.exe'))
    return str(options[-1]) if options else None


def measure():
    rows=[]
    git = get_git()
    all_tracked = set()
    if git:
        res = subprocess.run([git, '-C', str(repo), 'ls-files', '-z'], check=False, capture_output=True)
        if res.returncode == 0:
            all_tracked = {p.decode('utf-8', 'replace').casefold() for p in res.stdout.split(b'\0')}
    for role, base, paths in groups:
        for rel in paths:
            path = base / rel
            row = dict(role=role, path=str(path), exists=path.is_file())
            if path.is_relative_to(repo) and all_tracked:
                row['tracked'] = path.relative_to(repo).as_posix().casefold() in all_tracked
            if row['exists']:
                data=path.read_bytes()
                row.update(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
                if path.suffix.lower() in ('.m','.py','.md','.json','.txt','.asim','.mjs'):
                    row['lf_sha256'] = hashlib.sha256(data.replace(b'\r\n',b'\n')).hexdigest()
            rows.append(row)
    return dict(hostname=socket.gethostname(),files=rows)


if __name__=='__main__':
    print(json.dumps(measure(), ensure_ascii=True))
