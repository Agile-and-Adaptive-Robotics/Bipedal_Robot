import json
from pathlib import Path
import numpy as np
from scipy.io import loadmat
from source_hashes import repo, raw, training, lideng, accel, historical, tools, cad, hand, knee, spinal


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def compare_pairs(pairs):
    count = 0
    for left, right in pairs:
        with np.load(left, allow_pickle=False) as a, np.load(right, allow_pickle=False) as b:
            assert set(a.files) == set(b.files)
            for name in a.files:
                try:
                    x, y = a[name], b[name]
                except ValueError:
                    continue
                if x.dtype.kind in 'biufc':
                    assert np.array_equal(x, y, equal_nan=True), (left,name)
                    count += 1
    return count


out = {}
later = read(lideng/'FRESH_VERIFICATION.json')
new_ground = lideng/'fresh_repeat/W2L_VirtualWalker_Newer/repeat'
winner = next(p for p in (lideng/'body_trials').rglob('trajectory.npz') if 'trial_0010_' in str(p))
with np.load(new_ground/'trajectory.npz',allow_pickle=False) as z:
    names=z['joint_names'].tolist()
    lat=z['t']>=1
    bw=later['result']['robot_mass_kg']*9.81
    keys=['rail_force_world','guide_force_world','harness_force']
    out['W2L108_later'] = {
        'BWeight_N':bw, 'late_saved_window_s':[float(z['t'][lat][0]),float(z['t'][lat][-1])],
        'upward_support_percent_late':100*sum(np.maximum(z[k][lat,1],0).mean() for k in keys)/bw,
        'signed_net_support_percent_whole':100*sum(z[k][:,1].mean() for k in keys)/bw,
        'qualified_clear_swings_left_right':[later['assessment']['legs'][side]['unloaded_clear_swings'] for side in 'LR'],
        'knee_minimum_anatomical_deg_left_right':[later['assessment']['legs'][side]['min_anatomical_knee_flexion_deg'] for side in 'LR'],
        'belt_relative_displacement_m':later['result']['root_forward_relative_to_belt_m'],
        'selected_repeat_exact_numeric_arrays':compare_pairs([(new_ground/'trajectory.npz',winner)]),
        'rtf':later['result']['simulated_s_per_wall_s']}
old_ground=read(tools/'w2l108_graded/W2L_VirtualWalker_Newer/fresh_graded_ground/RESULT.json')
out['slide63']={k:old_ground[k] for k in ['neurons','nonspiking_edges','duration_completed_s','mean_net_vertical_assistance_BW','guide_clearance_m']}
human=read(hand/'records/GAIT_SUPPORT_DECOMPOSITION_5_TO_13.json')
out['slide65']={'window_s':human['window_s'], 'samples':human['samples'],
                'BW_N':human['body_weight_N'],'net_support_percent':100*human['support']['net_external_superior']['mean_fraction_bodyweight'],
                'horizontal_restraint_rms_N':human['horizontal']['restraint']['rms_magnitude_N'],
                'trace_sha256':human['trace_sha256']}
cad_result=read(cad/'FINAL_CHECKS.json')['clearance77p5_damped']
out['slide68']={k:cad_result[k] for k in ['evaluation_start_s','duration_s','unloaded_clear_intervals','mean_support_bw_evaluation_window','max_knee_every_step_deg','ground_step_gate']}
for key, directory in [('BiW2Lvar_plus','hunt_pose_air_validation_v3'),('syn6_ankle','syn6_ankle_selected_repeat_20261104')]:
    stages=[]
    for row in read(training/directory/'COMPLETE.json'):
        stage=row['stage']; result=row['principal_cycle_audit']
        with np.load(training/directory/f'stage{stage}/capture/aligned_trace.npz',allow_pickle=False) as z:
            labels=z['joint_names'].tolist()
            c=[z['joint_qpos_addresses'][labels.index('knee_angle_'+s)] for s in 'rl']
            stages.append(dict(stage=stage,accepted=row['accepted'],principal_knee_peaks_RL=result['principal_knee_cycles'],
                               complete_interpeak_intervals_RL=[max(0,n-1) for n in result['principal_knee_cycles']],
                               period_s=result['period_s'],knee_ranges_deg_RL=result['knee_ranges_deg'],phase_error=result['bilateral_phase_error'],
                               legacy_spring_fraction=row['measured']['mean_spring_support_bw'],ground=row['measured']['ground_enabled'],
                               max_abs_recorded_foot_force_N=float(np.max(np.abs(z['foot_force_anatomical_N']))),
                               maximum_native_knee_deg_RL=np.degrees(z['qpos'][:,c].max(axis=0)).tolist()))
    out[key]=stages
small=loadmat(knee/'replay_summary.mat',simplify_cells=True)
t=small['t']; c=small['C']; p=small['P']; fine=small['F']
base=c[(t>=25)&(t<30),0].mean()
delta=-np.degrees(p[:,0]-c[:,0]); ix=np.flatnonzero(t>=30)[np.argmax(delta[t>=30])]
displacement=-np.degrees(p[:,0]-base)
good=(np.abs(displacement)<=.01)&(np.abs(p[:,1])<=1e-4)
recover=t[np.flatnonzero((t>=30.03)&~good)[-1]+1]
out['reduced_knee']={'samples':len(t),'pulse_onset_s':30,'pulse_offset_s':30.03,
    'baseline_deg':-np.degrees(base),'excursion_vs_control_deg':delta[ix],'latency_s':t[ix]-30,
    'sustained_recovery_at_s':recover,'recovery_from_onset_s':recover-30,
    'recovery_from_offset_s':recover-30.03,'fine_step_max_delta_deg':float(np.degrees(np.abs(p[:,0]-fine[:,0])).max())}
out['earlier_benchmark']={}
for key in ['source_native_s1','source_baseline_s1']:
    tc=read(historical/f'timings/{key}/RESULT.json')
    rr=read(historical/f'configurations/{key}.result.json')
    out['earlier_benchmark'][key]={'external_s':tc['total_process_wall_s'],'neural_s':rr['compiled']['neural_step_wall_s'],
                                   'neurons':rr['compiled']['neurons'],'simulated_s':rr['simulated_s']}
suffs=['.npz','.assistance.npz','.contact_events.npz','.regional_contacts.npz','.mechanics.npz']
pair=[(historical/('configurations/source_native_s1'+s),historical/('configurations/source_baseline_s1'+s)) for s in suffs]
pair.append((historical/'figures/source_native_s1/aligned_trace.npz',historical/'figures/source_baseline_s1/aligned_trace.npz'))
out['earlier_benchmark']['identical_numeric_arrays']=compare_pairs(pair)
compact=read(accel/'results/VERIFIED_SUMMARY.json')
out['compact_benchmark']={k:{'neurons':v['compiled_scalars']['neurons'],'evaluator_wall_s':v['wall_s'],
        'neural_s':v['compiled_scalars']['neural_step_wall_s']} for k,v in compact['body'].items()}
suffs+=['.balance.npz','/capture/aligned_trace.npz']
out['compact_benchmark']['identical_numeric_arrays']=compare_pairs([(accel/('body/sparse_final'+s),accel/('body/compact_final'+s)) for s in suffs])
out['compact_benchmark']['isolated_hunt_kernel_3000_update_medians_s']={name:rec['median_s'] for name,rec in compact['families']['hunt']['timings_3000steps'].items()}
out['slide110']=[]
for case in read(historical/'figures/stage5_contact_strength_review/COMPARISON.json')['cases']:
    assess=case['independent_clearance']
    out['slide110'].append({'case':case['label'],'accepted':assess['accepted'],
             'whole_foot_clear_unloaded_swings_RL':[foot['sustained_clear_unloaded_swings'] for foot in assess['feet']]})
replay=read(spinal/'reports_20261027_codex/verification.json')
out['slides107_108']={k:replay[k] for k in ['identical_replays','full_saved_scalar_basin']}
original_pf=read(hand/'experiments_20261104/circuit_trace_20261105/syn6/timing_audit/PF_TIMING_AUDIT.json')
out['syn6_timing']={'original_passes':sum(bool(row['timing_gate']) for row in original_pf['rows']),
                     'original_checks':len(original_pf['rows'])}
for key,path in [('fixed_replay','syn6_native_20261105_v7/final_verified'),('adaptive_replay','syn6_adaptive_20261105/replay'),
                 ('adaptive_additional','syn6_adaptive_20261105/replay_live_range'),('live','syn6_adaptive_20261105/live_full_native'),
                 ('knee_relay_live','syn6_flexor_handover_20261105/predict150_live_timing')]:
    saved=read(training/path/'TIMING.json')
    if 'offline' in saved:
        conditions={scale:row['checks'] for scale,row in saved['offline'].items()}
    else:
        conditions={'closed_loop':saved['closed_loop']}
    out['syn6_timing'][key]={cond:{name:sum(val[side][name] for side in 'lr') for name in ('passed','checks')} for cond,val in conditions.items()}
Path(__file__).with_name('measured.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
