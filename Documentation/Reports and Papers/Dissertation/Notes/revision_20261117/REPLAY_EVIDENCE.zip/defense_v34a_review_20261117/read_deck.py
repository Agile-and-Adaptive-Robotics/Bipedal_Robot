import hashlib
import json
import os
import posixpath
import sys
import xml.etree.ElementTree as ET
from pathlib import Path
from zipfile import ZipFile

ns = {
    'p': 'http://schemas.openxmlformats.org/presentationml/2006/main',
    'a': 'http://schemas.openxmlformats.org/drawingml/2006/main',
    'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
    'pr': 'http://schemas.openxmlformats.org/package/2006/relationships',
}


def relations(z, member):
    directory, base = posixpath.split(member)
    rels = posixpath.join(directory, '_rels', base + '.rels')
    if rels not in z.namelist():
        return {}
    return {
        item.attrib['Id']: (item.attrib['Type'].rsplit('/', 1)[-1],
                            posixpath.normpath(posixpath.join(directory, item.attrib['Target']))
                            if item.get('TargetMode') != 'External' else item.get('Target'))
        for item in ET.fromstring(z.read(rels))
    }


def read_shapes(root):
    shapes = []
    for sp in root.findall('.//p:sp', ns):
        txbody = sp.find('p:txBody', ns)
        if txbody is None:
            continue
        paragraphs = []
        for par in txbody.findall('a:p', ns):
            line = ''.join(el.text or '' if el.tag.endswith('}t') else '\n'
                           for el in par.iter() if el.tag.endswith('}t') or el.tag.endswith('}br')).strip()
            if line:
                paragraphs.append(line)
        if not paragraphs:
            continue
        ph = sp.find('p:nvSpPr/p:nvPr/p:ph', ns)
        nv = sp.find('p:nvSpPr/p:cNvPr', ns)
        off = sp.find('p:spPr/a:xfrm/a:off', ns)
        styles = [int(x.get('sz', '0')) for x in txbody.iter() if x.get('sz', '').isdigit()]
        shapes.append(dict(name=nv.get('name'), placeholder=ph.get('type', '') if ph is not None else None,
                           x=int(off.get('x')) if off is not None else None,
                           y=int(off.get('y')) if off is not None else None,
                           size=max(styles, default=0), text='\n'.join(paragraphs)))
    return shapes


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_deck(source):
    deck = []
    with ZipFile(source) as z:
        presentation = 'ppt/presentation.xml'
        root = ET.fromstring(z.read(presentation))
        rels = relations(z, presentation)
        sects = {}
        for sect in root.iter():
            if sect.tag.endswith('}section') and sect.get('name'):
                for child in sect.iter():
                    if child.tag.endswith('}sldId'):
                        sects[child.get('id')] = sect.get('name')
        for index, slide_id in enumerate(root.find('p:sldIdLst', ns), 1):
            member = rels[slide_id.get('{'+ns['r']+'}id')][1]
            sl = ET.fromstring(z.read(member))
            srel = relations(z, member)
            note_member = next((v for k, v in srel.values() if k == 'notesSlide'), None)
            notes = []
            if note_member:
                notes = [obj['text'] for obj in read_shapes(ET.fromstring(z.read(note_member))) if obj['placeholder'] == 'body']
            shapes = read_shapes(sl)
            pictures = []
            for pic in sl.findall('.//p:pic', ns):
                prop = pic.find('p:nvPicPr/p:cNvPr', ns)
                blip = pic.find('p:blipFill/a:blip', ns)
                pictures.append(dict(name=prop.get('name','') if prop is not None else '',
                    description=prop.get('descr','') if prop is not None else '',
                    media=srel.get(blip.get('{'+ns['r']+'}embed'), ('',''))[1] if blip is not None else ''))
            deck.append(dict(index=index, file=member, id=slide_id.get('id'), section=sects.get(slide_id.get('id')),
                hidden=sl.get('show','1') in ['0', 'false'], shapes=shapes, notes=notes, pictures=pictures,
                media={rid:v for rid,v in srel.items() if v[0] in ('video', 'audio', 'media')},
                hash=sha(z.read(member)), notes_hash=sha(z.read(note_member)) if note_member else None))
    return deck


if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    here = Path(__file__).resolve().parent
    for source_name in sys.argv[1:]:
        source = Path(source_name)
        d = read_deck(source)
        (here / (source.stem + '.json')).write_text(json.dumps(d, indent=1, ensure_ascii=False), encoding='utf-8')
        for s in d:
            print(s['index'], 'hidden' if s['hidden'] else 'show', s['section'] or '',
                  ' | '.join(o['text'].replace('\n',' ')[:125] for o in s['shapes'][:4]))
