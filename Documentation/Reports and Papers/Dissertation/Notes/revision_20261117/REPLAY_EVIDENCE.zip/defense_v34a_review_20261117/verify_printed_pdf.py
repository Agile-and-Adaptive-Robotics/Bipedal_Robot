"""Extract the printable example without normalizing characters, and compare page bodies."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys
from PIL import Image

here=Path(__file__).resolve().parent
pdf=Path(sys.argv[1]).resolve()
directory=here/('pdf_'+pdf.parent.name)
manifest=json.loads((directory/'manifest.json').read_text(encoding='utf-8'))
data=subprocess.check_output(['pdftotext','-enc','UTF-8','-layout','-f',str(manifest['first']),
                              '-l',str(manifest['last']),str(pdf),'-']).decode('utf-8-sig')
pages=data.split('\f')
matches=[]
for n,page in enumerate(pages,manifest['first']):
    for line in page.splitlines():
        if line.strip().startswith('s = fullfile(pwd,'):
            matches.append((n,line.strip()))
assert len(matches)==1,matches
selected=[]; used=[]
for n,page in enumerate(pages,manifest['first']):
    if n < matches[0][0]:continue
    for line in page.splitlines():
        line=line.strip()
        if not selected and not line.startswith('s = fullfile(pwd,'):continue
        if not line or line.isnumeric():continue
        selected.append(line);used.append(n)
        if line=='isequaln(m,ref)':break
    if selected and selected[-1]=='isequaln(m,ref)':break
assert selected and selected[-1]=='isequaln(m,ref)',selected
text='\n'.join(selected)+'\n'
assert text.isascii(),ascii(text)
reference=(here/'replay_printed_example.m').read_text(encoding='utf-8').split('\nassert')[0]+'\n'
assert text==reference,(ascii(text),ascii(reference))
(here/'replay_from_pdf.m').write_text(text+'assert(isequaln(m,ref));\n',encoding='ascii')
old=here/'pdf_build_r2'
def page_hash(file):
    with Image.open(file) as img:
        return hashlib.sha256(img.crop((0,180,img.width,img.height)).tobytes()).hexdigest()
old_pages={page_hash(p):int(p.stem.split('-')[-1]) for p in sorted(old.glob('d-*.png'))}
matches={};changed=[]
for p in sorted(directory.glob('d-*.png')):
    number=int(p.stem.split('-')[-1])
    same=old_pages.get(page_hash(p))
    if same:matches[number]=same
    else:changed.append(number)
result=dict(pdf_sha256=manifest['sha256'],first=manifest['first'],last=manifest['last'],
            command_pages=sorted(set(used)),same_page_body_as_r2=matches,new_page_bodies=changed)
(directory/'comparison_to_r2.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(result)
