from pathlib import Path
from hashlib import sha256
from PIL import Image, ImageChops
import json
import re
import subprocess

here=Path(__file__).resolve().parent
notes=here.parents[1]/'Documentation/Reports and Papers/Dissertation/Notes/revision_20261117'
pdf=here.parent/'dissertation_revision_20261117/build_r4/main.pdf'
stored=notes/'KNEE_PDF_REPLAY_CHECK.json'
record=json.loads(stored.read_text(encoding='utf-8'))
before=record.get('pdf_used_for_matlab_execution_sha256',record['pdf_sha256'])
raw=subprocess.check_output(['pdftotext','-enc','UTF-8','-layout','-f','278','-l','278',str(pdf),'-']).decode('utf-8-sig')
lines=[s.strip() for s in raw.splitlines()]
start=next(n for n,line in enumerate(lines) if line.startswith('s = fullfile(pwd,'))
end=next(n for n,line in enumerate(lines) if line=='isequaln(m,ref)')
code=[s for s in lines[start:end+1] if s]
assert code==record['ascii_commands_extracted_from_pdf'] and len(code)==14
assert all(s.isascii() for s in code)
assert '\n'.join(code)+'\n' == (here/'replay_from_pdf.m').read_text().split('assert(isequaln')[0]
digest=sha256(pdf.read_bytes()).hexdigest()
print(f'All {len(code)} lines match the MATLAB-executed text, final SHA-256 {digest}',flush=True)
if (here/'pdf_build_r4/manifest.json').is_file():
    reference=json.loads((here/'pdf_build_r3/manifest.json').read_text(encoding='utf-8'))
    final=json.loads((here/'pdf_build_r4/manifest.json').read_text(encoding='utf-8'))
    assert (final['first'],final['last'],final['sha256'])==(269,309,digest)
    assert [p['printed'] for p in final['pages']]==[str(n) for n in range(249,290)]
    for n in range(269,310):
        name=f'd-{n}.png'
        with Image.open(here/'pdf_build_r4'/name) as a, Image.open(here/'pdf_build_r3'/name) as b:
            assert not ImageChops.difference(a,b).getbbox(),n
    record['pdf_used_for_matlab_execution_sha256']=before
    record['pdf_sha256']=digest
    record['delivered_pdf_check']={
        'exact_ASCII_lines_equal_to_executed_script':True, 'lines':14,
        'normalized_line_ending_sha256':sha256(('\n'.join(code)+'\n').encode('ascii')).hexdigest(),
        'source_pdf_for_matlab_execution_sha256':before,
        'delivered_pdf_sha256':digest,
        'all_41_full_page_renders_including_page_numbers_identical_to_execution_proof':True,
        'dpi':112}
    stored.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('Recorded all 41 page images and the code block as identical.')
