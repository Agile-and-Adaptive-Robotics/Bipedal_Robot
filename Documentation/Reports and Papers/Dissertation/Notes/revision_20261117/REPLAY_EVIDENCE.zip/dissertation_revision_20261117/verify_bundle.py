import hashlib
import json
import subprocess
import sys
import zipfile
from pathlib import Path
import pymupdf

repo=Path.cwd()
d=repo/"Documentation/Reports and Papers/Dissertation"
notes=d/"Notes/revision_20261117"
w=Path(__file__).resolve().parent
archive=notes/"Bolen_Dissertation_revised_sources.zip"
package=w/("package_rebuild_"+hashlib.sha256(archive.read_bytes()).hexdigest()[:12])
package.mkdir(exist_ok=False)
unpacked=package/"project"
with zipfile.ZipFile(notes/"Bolen_Dissertation_revised_sources.zip") as z:
    for name in z.namelist():
        assert (unpacked/name).resolve().is_relative_to(unpacked.resolve())
    z.extractall(unpacked)
result=subprocess.run([sys.executable,notes/"build_dissertation.py",package/"build",
                       "--source",unpacked/"Final"])
result.check_returncode()
ref = pymupdf.open(notes/"Bolen_Dissertation_revised.pdf")
copy = pymupdf.open(package/"build/main.pdf")
assert len(ref)==len(copy)
txt=[]
visual=[]
for i, (a,b) in enumerate(zip(ref,copy),1):
    if a.get_text()!=b.get_text():txt.append(i)
    ax=a.get_pixmap(dpi=100,alpha=False)
    bx=b.get_pixmap(dpi=100,alpha=False)
    if ax.digest!=bx.digest:visual.append(i)
report={"pdf_pages":len(ref),"different_extracted_text_pages":txt,"different_100_dpi_raster_pages":visual,
        "extracted_zip":str(unpacked),"verification_build":str(package/"build"),
        "source_zip_sha256":hashlib.sha256((notes/"Bolen_Dissertation_revised_sources.zip").read_bytes()).hexdigest()}
(notes/"PACKAGE_VERIFICATION.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
print(report)
assert not txt and not visual
