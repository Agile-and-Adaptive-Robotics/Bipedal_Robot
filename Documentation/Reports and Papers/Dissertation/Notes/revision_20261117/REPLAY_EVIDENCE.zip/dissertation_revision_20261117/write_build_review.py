import json
from pathlib import Path
w=Path(__file__).resolve().parent
notes=w.parents[1]/"Documentation/Reports and Papers/Dissertation/Notes/revision_20261117"
load=lambda name:json.loads((notes/name).read_text(encoding="utf-8"))
qa=load("FINAL_PROOF_CHECKS.json")
bundle=load("DELIVERY_HASHES.json")
package=load("PACKAGE_VERIFICATION.json")
replay=load("KNEE_PDF_REPLAY_CHECK.json")
assert package["source_zip_sha256"]==bundle["Bolen_Dissertation_revised_sources.zip"]["sha256"]
assert not package["different_extracted_text_pages"] and not package["different_100_dpi_raster_pages"]
build=Path(qa["engine_log"]).parent
source=notes.parents[1]/"Final/main.tex"
paper=notes/"Bolen_Dissertation_revised.pdf"
header_warnings=sum("PDFinclusion:foundPDFversion" in "".join(s.split()) for s in qa["pdftex_messages"])
text=f"""# Build and publication-size review

The build from `{source}` produced **{qa['pages']} pages**, {qa['bytes']:,} bytes, with SHA-256 `{qa['pdf_sha256']}`. The verified delivery is [Bolen_Dissertation_revised.pdf](Bolen_Dissertation_revised.pdf). [Machine-readable proof audit](FINAL_PROOF_CHECKS.json)

## Compilation

The build directory was created fresh at `{build}`, outside the working source. MiKTeX ran pdfLaTeX, BibTeX using the absolute source directory for BIBINPUTS and BSTINPUTS, and three more pdfLaTeX passes. All five processes exited successfully. The final log contains zero LaTeX warnings, unresolved citations or cross-references, overfull boxes, or oversized floats. BibTeX reported zero warnings. [Build driver](build_dissertation.py)

The engine issued {header_warnings} notices about the version headers of included PDFs and one duplicate `page.1` destination when `Final/main.tex:171` restarts the main matter. The class sets page 1 in `psutex.cls:168–169`. The engine emits the notice while shipping the first Introduction page at `10-introduction.tex:9`. There were {qa['underfull_hboxes']} underfull horizontal boxes and no underfull vertical boxes. The notices, raw log path, and individual graphic paths are retained in the proof audit. [Exact notices](FINAL_PROOF_CHECKS.json)

I extracted the **{bundle['Bolen_Dissertation_revised_sources.zip']['members']}-file** source bundle to an independent directory and compiled its own `Final/main.tex` with the bibliography and four pdfLaTeX passes. All {qa['pages']} pages had identical extracted text and a pixel-for-pixel match at 100 dpi. Each member of the source ZIP was checked byte-for-byte against its working source. Archive paths retain the `Final` and sibling `Figures` layout. The bundle includes both new Chapter 7 graphic panels and their alternative text. [Source bundle](Bolen_Dissertation_revised_sources.zip) · [Independent package build](PACKAGE_VERIFICATION.json) · [Delivery hashes](DELIVERY_HASHES.json)

## Rendered review

The {sum(b-a+1 for a,b in qa['section_pages'].values())} pages in the revised chapters and appendices were rendered at 144 dpi in `{build/"review"}`. We reviewed page transitions and captions, and used full-size pages or panels to inspect figures, axes, table borders, wrapping, and the runnable example. [Renderer and font audit](inspect_proof.py)

The final figure pass changed physical pages 263 and 264. The other 311 pages matched the previously reviewed proof in every pixel at 100 dpi. The 27 Chapter 6 pages and 41 Appendix D pages also matched at 144 dpi, with identical extracted text. The MATLAB listing copied from physical page 278 is therefore exactly the one that produced the archived response. [Whole-volume comparison](FINAL_PROOF_CHECKS.json) · [Delivered-PDF replay record](KNEE_PDF_REPLAY_CHECK.json)

| Section | Printed pages | Physical PDF pages | Checks and corrections |
|---|---:|---:|---|
| Chapter 6 | 133–159 | 153–179 | The independent reader inspected all 27 pages, eight figures, and four tables. The tables follow their introductory paragraphs. Figures no longer divide a results sentence across multiple pages. The W2L caption separates its 12–15 s display from its 4.5–30 s scoring interval. Extractable vector plot labels are at least 10.00 pt; the W2L graphic measures 11.61 pt and table type 10.91 pt. [Independent rendered review](INDEPENDENT_REVIEW.md) |
| Chapter 7 | 160–172 | 180–192 | Reviewed the design workflow, both proposed BPA panels and their joint caption, signed power formula, SADb pathway, and two hardware diagrams. Figure 7.2 sits between the element formulation and experimental conditions. The last two diagrams now fall between complete paragraphs. In the delivered Figure 7.2, the smallest labels are 10.50 pt. The two active vector PDFs and both alternative texts reproduced byte-for-byte. [Figure records](FIGURE_PROVENANCE.json) |
| Appendix A | 195–205 | 215–225 | Verified torque and moment-arm equations, full-vector and axial distinctions, cross-references, and the statement of the cable count. |
| Appendix B | 206–219 | 226–239 | Inspected model equations, aligned trace panels, captions, and surrounding page turns. |
| Appendix C | 220–248 | 240–268 | The initial coordinates now fit and Equation C11 shows the condyle arc integral. The pressure figure follows the complete sizing-study lead-in. On printed 243–244, 51 separate point callouts identify the original route at eight cam poses, with 10.79 pt labels. The full C5 key prints at 10.51 pt and includes the cam radius and five release angles. The unlabeled mechanical drawing is preserved. [Appendix review](APPENDIX_AC_E_EDITS.md) · [Cam figure review and provenance](CAM_FIGURE_PROVENANCE.md) |
| Appendix D | 249–289 | 269–309 | All 41 pages were inspected, including the eight graphics, comparison tables, and repeating source-map header. The 14-line MATLAB recipe is on printed 258, PDF 278. After the typography correction, copying that block from the PDF preserves the executable punctuation. All 13 JSON fields and all samples in the time vector and three arrays match the archive. [PDF-specific evidence](KNEE_PDF_REPLAY_CHECK.json) · [Appendix D review](APPENDIX_D_EDITS.md) |
| Appendix E | 290–293 | 310–313 | The pathway table in the earlier combined proof clipped its heading, caption, and outer rows despite a clean TeX log. The revised landscape table on the last PDF page fits all eight rows, counts, and citations at its original 10 pt setting. [Appendix review](APPENDIX_AC_E_EDITS.md) |

The actual PDF-extracted MATLAB commands, R2025a Update 1 result, input and output hashes, and page identity are preserved in the dated evidence. Ordinary TeX mathematical subscripts use the class's smaller math sizes. The 10 pt figure-label criterion was evaluated on labels at placed size. The new BPA illustrations show a proposed normalized profile and apparatus. They contain no experimental samples. [Knee replay](KNEE_PDF_REPLAY_CHECK.json) · [Figure sources](FIGURE_PROVENANCE.json)
"""
(notes/"BUILD_REVIEW.md").write_text(text,encoding="utf-8")
