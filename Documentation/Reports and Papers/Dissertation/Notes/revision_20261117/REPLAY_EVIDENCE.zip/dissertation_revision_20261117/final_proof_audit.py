from pathlib import Path
import argparse,json,hashlib,re
import pymupdf

w=Path(__file__).resolve().parent
notes=w.parents[1]/"Documentation/Reports and Papers/Dissertation/Notes/revision_20261117"
cli=argparse.ArgumentParser()
cli.add_argument("current",nargs="?",default="build_r4")
cli.add_argument("previous",nargs="?",default="build_r3")
opt=cli.parse_args()
build=w/opt.current
old=pymupdf.open(w/opt.previous/"main.pdf")
new=pymupdf.open(build/"main.pdf")
assert len(old)==len(new)
different=[]
text_changes=[]
for i,(a,b) in enumerate(zip(old,new),1):
    if a.get_text()!=b.get_text():text_changes.append(i)
    if a.get_pixmap(dpi=100,alpha=False).digest!=b.get_pixmap(dpi=100,alpha=False).digest:different.append(i)
def sh(p):return hashlib.sha256(p.read_bytes()).hexdigest()
log=(build/"main.log").read_text(encoding="utf-8",errors="replace")
warnings=re.findall(r"(?m)^pdfTeX warning[^\n]*\n(?:[^\n]*\n){0,2}",log)
fonts=[(s["text"],s["size"]) for block in new[183].get_text("dict")["blocks"] if "lines" in block for l in block["lines"] for s in l["spans"] if s["text"].strip()]
fea={text:round(size,3) for text,size in fonts if any(t in text for t in ["Axial diameter","Transition","Central span","Suspended load","Known weight","Uninflated diameter","fixture weight","End fitting","axial"])}
data={"pdf_sha256":sh(build/"main.pdf"),"pages":len(new),"bytes":(build/"main.pdf").stat().st_size,
      "engine_log":str(build/"main.log"),"latex_passes":len(list(build.glob("latex*.stdout"))),
      "latex_warnings":len(re.findall(r"(?m)^LaTeX Warning",log)),"overfull_boxes":log.count("Overfull \\"),
      "underfull_hboxes":log.count("Underfull \\hbox"),"underfull_vboxes":log.count("Underfull \\vbox"),
      "pdftex_messages":warnings,"bibtex_warning_count":int(re.search(r"warning\$ -- (\d+)",(build/"main.blg").read_text()).group(1)),
      "previous_reviewed_build":opt.previous,"visible_pages_changed_from_previous_100dpi":different,"text_or_layout_changes_from_previous":text_changes,
      "figure_7_2_text_size_points_in_printed_pdf":fea,
      "section_pages":{"Ch6":[133,159],"Ch7":[160,172],"A":[195,205],"B":[206,219],"C":[220,248],"D":[249,289],"E":[290,293]}}
(notes/"FINAL_PROOF_CHECKS.json").write_text(json.dumps(data,indent=2)+"\n",encoding="utf-8")
print(different,text_changes,fea,len(warnings),data["pdf_sha256"])
