import subprocess, io, json, hashlib, zipfile
from pathlib import Path
dis = Path("Documentation/Reports and Papers/Dissertation")
path = dis / "Bolen_Dissertation.zip"
notes = dis/"Notes/revision_20261117"
prior = subprocess.check_output(["git","show","HEAD:"+path.as_posix()])
new = path.read_bytes()
def h(b): return hashlib.sha256(b).hexdigest()
def read_index(raw):
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        return {i.filename:(h(z.read(i)),i.file_size) for i in z.infolist() if not i.is_dir()}
left, right = read_index(prior), read_index(new)
changed = {k: [left.get(k), right.get(k)] for k in sorted(left.keys()|right.keys()) if left.get(k)!=right.get(k)}
record = {"path":str(path.resolve()), "head_sha256":h(prior), "current_sha256":h(new), "old_file_count":len(left),"new_file_count":len(right),"different_members":changed}
def normalized(data):
    for enc in ("utf-8-sig","cp1252","latin-1"):
        try: return data.decode(enc).replace("\r\n","\n").rstrip("\n")
        except UnicodeError: continue
captured = Path("tmp/dissertation_revision_20261117/live")
with zipfile.ZipFile(io.BytesIO(new)) as archive:
    lookup={Path(i).name:i for i in archive.namelist() if not i.endswith("/")}
    record["captured_text_vs_current_zip"]={p.name:normalized(archive.read(lookup[p.name]))==normalized(p.read_bytes()) if p.name in lookup else None for p in captured.iterdir()}
with zipfile.ZipFile(io.BytesIO(prior)) as old_zip,zipfile.ZipFile(io.BytesIO(new)) as new_zip:
    import difflib
    record["old_to_current_ch6_diff"]="".join(difflib.unified_diff(
      normalized(old_zip.read("chapters/60-sns.tex")).splitlines(keepends=True),
      normalized(new_zip.read("chapters/60-sns.tex")).splitlines(keepends=True),n=0))
print(json.dumps(record,indent=2)[:2000])
(notes/"CONCURRENT_ZIP.json").write_text(json.dumps(record,indent=2)+"\n",encoding="utf-8")
