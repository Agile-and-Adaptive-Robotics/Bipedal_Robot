import collections
import html
import json
import re
from pathlib import Path

w=Path(__file__).resolve().parent
d=w.parents[1]/"Documentation/Reports and Papers/Dissertation"
notes=d/"Notes/revision_20261117"
review=json.loads((notes/"LIVE_REVIEW.json").read_text(encoding="utf-8-sig"))
live={p.name:p.read_text(encoding="utf-8") for p in (w/"live").iterdir()}
final={p.name:p.read_text(encoding="utf-8-sig") for p in (d/"Final/chapters").glob("*.tex")}
def locate(filename,term):
    return next((i for i,s in enumerate(final[filename].splitlines(),1) if term in s),None)
def label(filename,term):
    return filename+":"+str(locate(filename,term))
rows=[]
def put(group,id,where,old,new,why,status):
    rows.append(dict(group=group,id=id,where=where,old=old,new=new,why=why,status=status))
peeranchors={2744:"Linked tables",3637:"keyword searches",3741:"I initially imported ",6114:"Results: Application and Corpus",7009:"Louvain",12991:"AI-Assisted Literature ",15634:"locomotor phase patterns. Following the source papers exposes these differences in task, preparation, and explanation.",15754:"C",16414:" pathway "}
advisor_why=["Name the motivating project before describing controller transfer.","Identify the interface as connecting neural output to an actuator command.","Use the preposition appropriate to the physical interface."]
at=ac=0
def addline(entry):
    n=entry["offset"]
    s=live[entry["file"]]
    return f'{entry["file"]}:{s[:n].count(chr(10))+1} (live), character {n:,}, {entry["time"]}.'
for e in review["entries"]:
    if e["author"]!="ajh26":continue
    loc=addline(e)
    if e["kind"]=="replace":
        newhere=label("60-sns.tex","starting point was") if at==0 else label("60-sns.tex","connect neural outputs with actuator commands")
        put("Advisor",f"AD-T{at+1} · −1",loc+" Revised "+newhere,e["original"],e["proposed"],
            advisor_why[at]+" "+("Issue 1, linked to AD-C1/C2." if at==0 else "Issue 2, paired command wording."),"Answered locally; live change awaits Ben.")
        at+=1
    else:
        for msg in e["messages"]:
            ac+=1
            where=loc+" Message "+msg["time"]+"; "+label("60-sns.tex","A neuromechanical simulation")
            put("Advisor",f"AD-C{ac} · −{ac}",where,e["anchor"]+"\n\n"+msg["text"],final["60-sns.tex"].splitlines()[locate("60-sns.tex","A neuromechanical simulation")-1],
                ("Clarification. " if ac==1 else "Substantive reorganization. ")+"Issue 1. Define the loop before the historical transfer and explain why the fall prompted controlled tests.","Answered locally and verified on reread; live thread awaits Ben.")
for i,line in enumerate((w/"directives.txt").read_text(encoding="utf-8").splitlines(),1):
    key,old,loc,new,why=(column.replace("\\\\","\\") for column in line.split(" | "))
    put("Author directive",f"U{i:02}",key+" · "+loc,old,new,why,"Applied locally or verified as stated.")
ind=json.loads((notes/"INDEPENDENT_FINDINGS.json").read_text(encoding="utf-8"))
iref=["60-sns.tex|A neuromechanical simulation","60-sns.tex|Tools I developed or adapted","95-AppendixD.tex|Running the knee experiment","60-sns.tex|Adjusting synaptic gains alone","70-overall.tex|shared descending drive","95-AppendixD.tex|In the bilateral-RG W2L circuit","95-AppendixD.tex|sustained","95-AppendixD.tex|handover","92-AppendixA.tex|signed tendon-excursion","92-AppendixA.tex|unsigned","92-AppendixA.tex|row 77","94-AppendixC.tex|inferred re-engagement","93-AppendixB.tex|spiking","96-AppendixE.tex|plantaris","96-AppendixE.tex|382","70-overall.tex|controller hardware-in-the-loop","70-overall.tex|SADb lets a researcher","30-torque.tex|based on bones scans","92-AppendixA.tex|assembly uses"]
for item,target in zip(ind,iref):
    filename,term=target.split("|")
    loc=locate(filename,term)
    extra=f" Revised {filename}:{loc}." if loc else " Revised section and exact passages are in the independent reread."
    put("Independent finding",item["id"],item["location"]+"; "+item["also"]+extra,item["original_full_line"],
        item["proposed_change"],item["rationale"],"Ben's decision, Chapter 4 is outside this edit." if item["id"]=="IR18" else "Applied locally; see the independent reread.")
screen=json.loads((notes/"CLASSIFIER_RESULTS.json").read_text(encoding="utf-8"))
recheck=json.loads((notes/"INDEPENDENT_REREAD.json").read_text(encoding="utf-8"))
passages={(a["file"],a["start"]):a for a in screen["paragraph_outputs"]}
for i,item in enumerate(recheck["predicted_passage_reread"],1):
    orig=passages[item["file"],item["original_live_line"]]
    refs=", ".join(r["file"]+":"+str(r["first_line"]) for r in item["revised_locations"])
    revised_snippets=[]
    for location in item["revised_locations"][:2]:
        sliced=final[location["file"]].splitlines()[location["first_line"]-1:location["last_line"]]
        revised_snippets.extend(x for x in sliced if x.strip() and not x.startswith("%"))
    proposed=item["rationale"]+("\n\n"+revised_snippets[0] if revised_snippets else "")
    put("Classifier inspection",f"LM-{i:03}",item["file"]+":"+str(item["original_live_line"])+" live · proposed inspection priority "+str(item["original_prediction"])+" · revised "+refs,
        orig["input"],proposed,orig["model_reason"],"Addressed locally." if item["decision"]=="addressed" else "Retained after independent inspection; rationale in this row.")
for item in recheck["followup_findings"]:
    displayed="\n".join(s.get("revised_excerpt","") for s in item.get("evidence",[]))
    put("Independent reread",item["id"],item["location"],item["original_intermediate"],displayed,item["judgement"],item["disposition"].replace("_"," "))
for num,old,new,why,where,status in [
  ("01","the muscle's maximum isometric force","Describe the pose-dependent torque and moment-arm exports that the optimizer actually uses.","The measured torque-to-arm ratios vary across all 100 matched poses. A fixed F0 cannot reproduce either curve.","30-torque.tex:451; revised Appendix A, reference torque","Ben's decision, outside this edit."),
  ("02","Supported Gait2392","Identify the embedded movie as the CAD ideal-tension experiment, or select the actual human-model clip.","The movie is byte-identical to slide 68. The genuine human trial uses a different support system.","Defense v34a slide 76; slides 65, 68, and 109","Ben's decision for the deck. Manuscript uses the verified model."),
  ("03","Reciprocal inhibition of the flexor as an explanation of the measured extension.","Attribute initial movement to the increase in extensor force. Preserve later flexor recruitment.","Flexor tension was negligible during the 30 ms pulse, then reached 14.4 N before peak extension.","60-sns.tex sensory pulse; 95-AppendixD.tex at pulse onset","Applied locally and rechecked against native samples."),
  ("04","‘cycles’ in the suspended trials, 4 and 7 per side.","Report four and seven principal knee-flexion peaks, representing three and six complete intervals per side.","The extrema counter and adjacent-peak periods measure different quantities.","60-sns.tex suspended trials and 95-AppendixD.tex BiW2Lvar+","Applied locally and rechecked from original arrays."),
  ("05","Closed loop in the E1 interface run.","Describe the saturating length transducer and restrict the observation to bidirectional exchange.","The length encoder saturated on all 300 noninitial samples.","60-sns.tex bridge check; 95-AppendixD.tex signal contract","Applied locally and verified."),
  ("06","Combined deletion as unspecified Ia, II, and Ib feedback loss.","Identify actual heel/toe and side-pooled Ib ports, the 35 changes, common push, and the isolated-Ib comparison.","A relay's name does not prove that the walker received a physical stretch measurement.","60-sns.tex sensory removal; 95-AppendixD.tex W2L test","Applied locally and verified in three fresh replays."),
  ("07","Archived slide 63 support figure versus the later W2L108 result.","Distinguish 39.2379% from the later 29.5188% upward and 35.0686% signed figures.","The runs, force sign convention, apparatus, and scoring windows differ.","Defense slides 63, 99; W2L108 in Ch 6 and App D","Verified; no change to original recorded percentages."),
  ("08","Exploded construction panels with specific layer contacts.","Use a proposed axial-profile diagram and free, loaded, and fixed-length experiments.","The manufacturer documents reinforcement. It does not specify each inferred internal slip interface.","70-overall.tex Figure 7.2; Festo DMSP datasheet p. 2","Applied locally, originals archived."),
  ("09","A model-specific physical threshold given without a route to its definition.","Link the physical criteria in the main chapter to the appendix's force, clearance, and duration criteria.","The CAD 80 ms interval is configuration specific.","60-sns.tex physical acceptance paragraph","Applied locally."),
  ("10","Do new users know where to run the graphical editor and bridge check?","Give the SNSGui directory/constructor, named bridge invocation and expected sample count and sensor agreement.","Labels in a capability table alone do not supply a reproducible first action.","60-sns.tex SNSGui editor; 95-AppendixD.tex script map","Applied locally."),
  ("11","The original live end paragraph was renamed Opportunities for Further Integration.","Retain the revised purpose and give concrete PF transfer, muscle-force, and embedded-controller experiments.","This preserves the substantive live reordering and lets the reader identify the input and outcome.","60-sns.tex, discussion","Reconciled locally."),
  ("12","Apparent exact assumptions for the first converted-muscle derivative or anatomical audit.","Use the script map and worked sensory replay. Treat the separately configured mechanical-audit recipes as entry points.","The complete printed reproduction contract covers the sensory-pulse experiment. Some earlier data sources remain machine-local.","TECHNICAL_READER.md, reread; Appendix D script map","Documented coverage and dependencies."),
  ("13","Long technical tables, multiple floats in mid-sentence, and MATLAB typography in the first full proof.","Adjusted float breaks, landscape pathway table, and printed MATLAB command presentation. Reinspected revised page transitions.","The reader must be able to follow uninterrupted result paragraphs, read table edges, and paste the example.","Rendered Chapters 6 and 7 and Appendices D and E","Applied locally; see BUILD_REVIEW.md."),
  ("14","Several position labels cluster around the distal contact points at the early cam poses.","Replaced the overprinted labels with 51 separate callouts on eight poses. All callouts were checked against the saved fitted MAT.","The plotted points are close at these angles. The unchanged underlying artwork and the coordinate checks identify the original points.","Printed Appendix C, Figures C4/C5 on 243–244; CAM_LABEL_VERIFICATION.json","Applied locally. Confirmed at print size in the delivered proof."),
  ("15","Duplicate PDF destination page.1, ignored by the engine.","If revising front matter, make the front-matter destination names distinct when restarting Arabic page numbering.","This is an existing document-level hyperlink destination diagnostic. Chapters, the bibliography, and authored cross-references resolve.","Final/main.tex:171; psutex.cls:168–169. Emitted while shipping chapters/10-introduction.tex:9.","Documented for Ben. Outside this manuscript edit."),
  ("16","The standalone flexor evaluator header describes both a two-rotation convention and a mixed convention.","Reconcile the standalone source comments with its implemented transforms, keeping the historical fitting executable and saved parameters distinct.","The executable standalone lines use the first rotation at both brackets. The historical row-77 fit used the stored 2trans mode in a separate evaluator.","Testing_Data/2022_02_Festo/minimizeFlxPin.m:4–7, 289, and 306; fitted source minimizeFlxPin2brk.m:277 and 297.","Appendices corrected locally. Code and standing repository documentation require a separate author decision."),
  ("17","The bend-radius legend swatch uses the PDF dash operator without its phase operand.","Supplied zero phase and confirmed all 11 legend entries, the 96.9 mm radius, and the five release-angle values in the printed figure.","An invalid dash operator truncated the legend in Poppler. The missing legend entries and release-angle text change what a reader can see.","Appendix C, Figure C5, bend-radius legend swatch, printed page 244","Applied locally and confirmed in the delivered PDF with Poppler.")
]:
    put("Technical or defense finding","X"+num,where,old,new,why,status)

for section,file in [("AC","APPENDIX_AC_E_EDITS.md"),("D","APPENDIX_D_EDITS.md"),("TR","TECHNICAL_READER.md")]:
    sub=""; count=0; reread=False
    for line in (notes/file).read_text(encoding="utf-8-sig").splitlines():
        if line.startswith("## "): sub=line[3:]; reread="Rereading" in sub
        if section=="TR" and not reread:continue
        if not line.startswith("|"):continue
        c=[s.strip() for s in line.strip(" |").split("|")]
        if len(c)!=3 or c[0] in ("Original lines","Original line and anchor","My original question and location","---") or c[0].startswith("--"):continue
        if section=="AC" and not c[0][0].isdigit():continue
        if section=="D" and sub!="Pass through the appendix":continue
        if section=="TR" and not c[0].endswith(".") and "Original" not in c[0]:continue
        count+=1
        old,proposed=c[:2]
        if section=="D":
            def excerpt(lines,coordinates):
                result=[]
                for a,b in re.findall(r"(\d+)(?:[–-](\d+))?",coordinates):
                    result.extend(lines[int(a)-1:int(b or a)])
                return "\n".join(result)
            old=c[0]+"\n\n"+excerpt(live["95-AppendixD.tex"].splitlines(),c[0])
            proposed=c[1]+"\n\n"+excerpt(final["95-AppendixD.tex"].splitlines(),c[1])
        put("Technical or defense finding",f"{section}-{count:02}",file+" · "+sub,old,proposed,c[2],"Local revision and source check recorded in "+file)
peer=auth=0
for e in review["entries"]:
    if e["author"]=="ajh26":continue
    loc=addline(e)
    if e["kind"]=="thread":
        peer+=1
        anchor=e.get("anchor")
        if not anchor and e["file"]=="50-database.tex":anchor=peeranchors.get(e["offset"])
        if anchor:
            e["anchor"]=anchor;e["anchor_capture"]="Exact highlighted live editor text"
        else:
            e["anchor_capture"]="The live editor showed no selected text at this thread position."
        old=anchor or "No surviving highlighted text at the recorded position."
        msgs="\n\n".join(m["author"]+" · "+m["time"]+"\n"+m["text"] for m in e["messages"])
        if e["file"]=="60-sns.tex":
            why="The six detached Chapter 6 threads ask about controller and model identity, motivation, coupling, simulation, MATLAB reproduction, and the chapter roadmap. The rewritten opening, tools table, and worked example address these issues."
            status="Addressed in local rewrite at Ch 6 opening and methods; historical anchor is detached."
        else:
            why="Earlier review of the abstract or Chapter 5. The live discussion and any replies are preserved for the author. The Chapter 7 pathway example answers related navigation feedback."
            status="Ben's decision in the live project; source outside this edit."
        put("Peer review",f"PEER-{peer:02}",loc,old,msgs,why,status)
    else:
        auth+=1
        why="Author's recorded "+e["kind"]+" shown in the live Review panel. The source reconciliation used the visible proposed text."
        stat=("Recorded; any live acceptance or rejection belongs to Ben." if e["file"] not in {"60-sns.tex","70-overall.tex","92-AppendixA.tex","93-AppendixB.tex","94-AppendixC.tex","95-AppendixD.tex","96-AppendixE.tex"} else
              "Reconciled with local revisions; any live acceptance or rejection belongs to Ben.")
        put("Author tracked edit",f"EDIT-{auth:03}",e["author"]+" · "+loc,e["original"],e["proposed"],why,stat)
anchors=[{k:e.get(k) for k in ("file","offset","anchor","anchor_capture","time")} for e in review["entries"] if e["kind"]=="thread"]
(notes/"LIVE_THREAD_ANCHORS.json").write_text(json.dumps(anchors,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
assert (at,ac,peer,auth)==(3,2,20,363),(at,ac,peer,auth)
groups=collections.Counter(r["group"] for r in rows)
def esc(s):return html.escape(str(s),quote=True)
def block(s):
    if s=="":return '<span class="empty">Empty string</span>'
    h=esc(s)
    if len(s)>400:return '<details><summary>'+esc(s[:170])+'…</summary><div>'+h+'</div></details>'
    return h
out=['''<!doctype html><html lang="en"><meta charset="utf-8"><title>Dissertation revision review</title>
<style>body{font:16px/1.45 "Segoe UI",Arial,sans-serif;color:#192c36;margin:25px;background:#fff}h1{font-size:29px;margin:0}p{max-width:100ch}table{width:100%;border-collapse:collapse;table-layout:fixed;font-size:14px}th{background:#17394b;color:white;text-align:left;position:sticky;top:0}td,th{padding:9px;border:1px solid #c3ccd0;vertical-align:top;overflow-wrap:anywhere}tr:nth-child(even){background:#f4f7f8}td{white-space:pre-wrap}.empty{color:#54646d;font-style:italic}label{margin-right:12px}input,select{font:inherit;padding:5px}summary{cursor:pointer}details div{margin-top:6px}a{color:#145779}@media print{th{position:static}nav{display:none}thead{display:table-header-group}}</style>
<h1>Dissertation revision review</h1><p>Source locations labeled “live” use the captured working text and zero-based character offsets. Manuscript line numbers refer to the local edition cited in each finding. The advisor gave five scored signals on two issues, totaling −6. Peer comments, the author’s tracked edits, and independent findings have distinct sources. All live dispositions belong to Ben.</p>''']
descriptions={"Advisor":"advisor signals","Author directive":"author directives","Independent finding":"independent findings",
              "Classifier inspection":"unlabeled passages inspected","Independent reread":"reread findings",
              "Technical or defense finding":"technical, defense, and proof records",
              "Author tracked edit":"author tracked edits","Peer review":"peer threads"}
out.append('<p>Review records include '+', '.join(f'{n} {descriptions[group]}' for group,n in groups.items())+'. Long passages expand to their full text. <a href="LIVE_REVIEW.json">Verbatim live capture</a> · <a href="INDEPENDENT_REVIEW.md">Classifier review</a> · <a href="TECHNICAL_READER.md">Technical reread</a></p>')
out.append('<nav><label>Source <select id="kind"><option value="">All sources</option>'+''.join('<option>'+esc(g)+'</option>' for g in groups)+'</select></label><label>Search <input id="term" type="search"></label><output id="count"></output></nav><p></p><table><colgroup><col style="width:10%"><col style="width:15%"><col style="width:19%"><col style="width:22%"><col style="width:20%"><col style="width:14%"></colgroup><thead><tr>'+''.join('<th>'+s+'</th>' for s in ["Source and ID","Location","Original wording or anchor","Proposed wording or action","Reason and evidence","Disposition"])+'</tr></thead><tbody>')
for row in rows:
    out.append('<tr data-group="'+esc(row["group"])+'"><td>'+esc(row["group"])+'<br><b>'+esc(row["id"])+'</b></td>'+''.join('<td>'+block(row[k])+'</td>' for k in ["where","old","new","why","status"])+'</tr>')
out.append('''</tbody></table><script>const menu=document.querySelector("#kind"),term=document.querySelector("#term"),count=document.querySelector("#count"),rows=[...document.querySelectorAll("tbody tr")];function filter(){let total=0;for(const row of rows){row.hidden=Boolean((menu.value&&row.dataset.group!==menu.value)||!row.textContent.toLowerCase().includes(term.value.toLowerCase()));if(!row.hidden)total++}count.textContent=total+" visible rows"}menu.addEventListener("change",filter);term.addEventListener("input",filter);filter()</script></html>''')
(notes/"REVIEW_TABLE.html").write_text("\n".join(out),encoding="utf-8")
print(dict(groups),len(rows))
