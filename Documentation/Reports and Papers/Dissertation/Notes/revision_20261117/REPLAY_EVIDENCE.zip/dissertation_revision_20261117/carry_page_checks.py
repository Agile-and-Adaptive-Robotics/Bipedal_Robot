"""Link earlier independent readings and a MATLAB execution to byte-identical page renderings in delivery."""
import hashlib,json,re,sys
from pathlib import Path
import pymupdf

w=Path(__file__).resolve().parent
notes=w.parents[1]/"Documentation/Reports and Papers/Dissertation/Notes/revision_20261117"
local=w/sys.argv[1]/"main.pdf"
prior=w/"build_r4/main.pdf"
new=pymupdf.open(local)
old=pymupdf.open(prior)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def compare(a,b):
    for i in range(a-1,b):
        pa,pb=old[i],new[i]
        assert pa.get_text()==pb.get_text(),i+1
        assert pa.get_pixmap(dpi=144,alpha=False).digest==pb.get_pixmap(dpi=144,alpha=False).digest,i+1
compare(153,179)
compare(269,309)
record=notes/"KNEE_PDF_REPLAY_CHECK.json"
j=json.loads(record.read_text(encoding="utf-8-sig"))
if j["pdf_sha256"]!=sha(local):
    j["previous_independently_reviewed_pdf_sha256"]=j["pdf_sha256"]
j.update({"pdf_sha256":sha(local),"delivery_page_comparison":{"prior_document_sha256":sha(prior),
          "physical_range":[269,309],"render_dpi":144,"all_page_rasters_and_extracted_text_identical":True,
          "matlab_recipe_page":278,"copied_recipe_identical_to_executed_recipe":True}})
record.write_text(json.dumps(j,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
recheck=notes/"INDEPENDENT_REREAD.json"
j=json.loads(recheck.read_text(encoding="utf-8-sig"))
j["delivery_crosscheck"]={"pdf_path":str(local),"pdf_sha256":sha(local),"source_proof_sha256":sha(prior),"physical_range":[153,179],
                          "render_dpi":144,"all_chapter_6_page_rasters_and_text_identical":True,
                          "scope":"Independent reader inspected this Chapter 6 layout and prose in the prior proof. Root verified the delivered copy."}
recheck.write_text(json.dumps(j,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
print("27 Chapter 6 and 41 Appendix D pages matched in all pixels and extracted text")
