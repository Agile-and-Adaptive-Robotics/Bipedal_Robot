"""Check package contents, protected files, labels, inventories, and the single review table."""
import collections
import hashlib
import json
import re
import subprocess
import zipfile
from html.parser import HTMLParser
from pathlib import Path

repo=Path.cwd()
dis=repo/"Documentation/Reports and Papers/Dissertation"
notes=dis/"Notes/revision_20261117"
active=dis/"Final"
review=json.loads((notes/"LIVE_REVIEW.json").read_text(encoding="utf-8-sig"))
classifier=json.loads((notes/"CLASSIFIER_RESULTS.json").read_text(encoding="utf-8"))
independent=json.loads((notes/"INDEPENDENT_REREAD.json").read_text(encoding="utf-8"))
dst=json.loads((notes/"DELIVERY_HASHES.json").read_text(encoding="utf-8"))
def sh(b):return hashlib.sha256(b).hexdigest()
def norm(b):return b.replace(b"\r\n",b"\n")
def git_version(p):return subprocess.check_output(["git","show","HEAD:"+p.relative_to(repo).as_posix()])
assert sh((notes/"LIVE_REVIEW.json").read_bytes())==classifier["review_capture_sha256"].lower()
protected=[]
protected_graphics=[]
scoped={"60-sns.tex","70-overall.tex","92-AppendixA.tex","93-AppendixB.tex","94-AppendixC.tex","95-AppendixD.tex","96-AppendixE.tex"}
active_files=[p for p in active.rglob("*") if p.is_file()]
for p in active_files:
    if p.name in scoped:continue
    assert norm(p.read_bytes())==norm(git_version(p)),p
    protected.append({"file":p.relative_to(dis).as_posix(),"local_sha256":sh(p.read_bytes())})
with zipfile.ZipFile(notes/"Bolen_Dissertation_revised_sources.zip") as z:
    for name in z.namelist():
        assert z.read(name)==(dis/name).read_bytes(),name
        if name.startswith(("Figures/10-introduction/","Figures/20-muscles/")):
            graphic=dis/name
            working=graphic.read_bytes()
            stored=git_version(graphic)
            eol_only=graphic.suffix.lower()==".eps" and working.startswith(b"%!PS") and norm(working)==norm(stored)
            assert working==stored or eol_only,graphic
            protected_graphics.append({"file":name,"sha256":sh(working),"git_raw_sha256":sh(stored),
                                       "comparison":"identical bytes" if working==stored else "identical apart from Git working-tree line endings"})
    for p in active_files:assert p.relative_to(dis).as_posix() in z.namelist()
for name,record in dst.items():assert sh((notes/name).read_bytes())==record["sha256"]
class CountTable(HTMLParser):
    def __init__(self):super().__init__();self.groups=collections.Counter();self.tables=0
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if tag=="table":self.tables+=1
        if tag=="tr" and "data-group" in a:self.groups[a["data-group"]]+=1
table=CountTable()
table.feed((notes/"REVIEW_TABLE.html").read_text(encoding="utf-8"))
assert table.tables==1 and table.groups["Advisor"]==5 and table.groups["Peer review"]==20 and table.groups["Author tracked edit"]==363
assert table.groups["Classifier inspection"]==len(independent["predicted_passage_reread"])==130
ch7=(active/"chapters/70-overall.tex").read_text(encoding="utf-8")
assert "staggered flexor paths need" not in ch7 and r"\chi_{4}" not in ch7 and "reeved routes" not in ch7
assert r"P=\tau\omega" in ch7 and r"\citep[p.~2]{festo_2026}" in ch7 and "controller hardware-in-the-loop" in ch7
assert "tension-only truss" in ch7 and "counterbalanced" in ch7 and "Fig" in ch7
assert len(review["entries"])==387
pkg=json.loads((notes/"PACKAGE_VERIFICATION.json").read_text(encoding="utf-8"))
assert pkg["source_zip_sha256"]==dst["Bolen_Dissertation_revised_sources.zip"]["sha256"] and not pkg["different_extracted_text_pages"] and not pkg["different_100_dpi_raster_pages"]
out={"protected_sources":protected,"review_table_count":table.tables,"review_rows":dict(table.groups),
     "untouched_included_graphics_from_introduction_and_published_muscle_chapter":protected_graphics,
     "rows_total":sum(table.groups.values()),"original_review_matches_classifier_input_sha256":True,
     "delivered_zip_members_all_match_local_files":True,"all_seven_requested_sources_in_bundle":True,
     "no_manuscript_build_artifacts_in_Final":len(active_files)==23}
assert out["no_manuscript_build_artifacts_in_Final"]
(notes/"FINAL_DELIVERY_AUDIT.json").write_text(json.dumps(out,indent=2)+"\n",encoding="utf-8")
print(out["rows_total"],"review rows;",len(protected),"protected source files verified")
