import subprocess
from pathlib import Path
repo=Path.cwd()
dis=repo/"Documentation/Reports and Papers/Dissertation"
notes=dis/"Notes/revision_20261117"
manifest=(notes/"COMMIT_FILES.txt").read_text(encoding="utf-8").split("Changes present when work began")[0]
selected={Path(l).resolve().relative_to(repo).as_posix() for l in manifest.splitlines() if l.startswith(str(repo)+"\\")}
raw=subprocess.check_output(["git","status","--porcelain=v1","-z","--untracked-files=all"])
changed={r[3:].decode("utf-8") for r in raw.split(b"\0") if r}
incoming={(dis/"Bolen_Dissertation.zip").relative_to(repo).as_posix()}
assert selected|incoming==changed,(sorted(changed-selected-incoming), sorted(selected-changed))
assert subprocess.run(["git","diff","--cached","--quiet"]).returncode==0
assert subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()=="316dea36d83919c535908cd954d2381c37006845"
print(len(selected),"requested paths in the manifest and Git status; one separate incoming archive; zero staged changes.")
